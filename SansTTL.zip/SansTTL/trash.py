import matplotlib.pyplot as plt

X,  X_factors3 = [0.5,0.8,0.9], [1,2,3]
plt.plot(X,  X_factors3 , label='test')

a = 0.8

plt.xlabel('solving duration in seconds')
plt.ylabel('x factor')
plt.title('X factor')
plt.legend( prop={"size":2})
ax = plt.subplot(111)
plt.subplots_adjust(top=0.85)
box = ax.get_position()
ax.set_position([box.x0, box.y0, box.width * 0.8, box.height])
# Put a legend to the right of the current axis
ax.legend(loc='center left', bbox_to_anchor=(1, 0.5),prop={"size":6})
plt.text(0.95,1.8,'différence'+ ' ' +str(a))
plt.savefig('test.png')
plt.show()
print(box.x0*3, box.y0*10)
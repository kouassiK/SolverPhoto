import os
#import Code
import pathlib
import xlsxwriter
import ConfigInterface
import xml.etree.ElementTree as ET

def FindSolutionPath():
    """
    Find the name path of file
    """
    path = os.getcwd()
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == "Solution.xml" ):
            found = filepath
    return found

def GetNumberMasksTransfers():
    """
    Get the number of masks transfer

    """
    with open('Solution.xml', 'rt') as f:
        tree = ElementTree.parse(f)
    number_masks_transfers = 0
    for node in tree.iter():
        if(node.tag == "OutputMaskTransfer"):
            number_masks_transfers = number_masks_transfers + 1 
            
    print(number_masks_transfers)
    return number_masks_transfers


def GetNumberTemperatureChanges():
    """
    Get the number of changing temperatures 

    """
    with open('Solution.xml', 'rt') as f:
        tree = ElementTree.parse(f)
    number_temperature_change = 0
    for node in tree.iter():
        if(node.tag == "OutputChangeover"):
            number_temperature_change = number_temperature_change  + 1 
            
    print(number_temperature_change)
    return number_temperature_change
    

def SaveValues(filepath):
    """
    Get the values of the indicators in Solution.xml
    
    """
    tree = ET.parse(filepath.name)
    root = tree.getroot()
    #Recuperate results
    result = []
    xFactor = root[1][2].text
    numberOfMoves = root[1][0].text
    targetSatisfactionIndicator = root[1][1].text
    result = [xFactor, numberOfMoves, targetSatisfactionIndicator,GetNumberMasksTransfers(), GetNumberTemperatureChanges()]
    
    #Conversion des paramètres
    print(result)
    return result
    
FindSolutionPath()

#SaveValues()




'''def ExcelTemplate(name):
    """
    Create the template to stock the values the values of each parameter which can be modified for the simulation
    """
    #Excel file creation
    #name = Code.SelectInputData()
    global worbook
    global worksheet1
    global worksheet2
    global worksheet3
    global worksheet4
    global worksheet5


    workbook = xlsxwriter.Workbook(name + '.xlsx')
    worksheet1 = workbook.add_worksheet("SOLVING_DURATION_IN_MINUTES")
    worksheet2 = workbook.add_worksheet("MOVES_WINDOW_IN_HOURS")
    worksheet3 = workbook.add_worksheet("MULTICRITERIA_MODE") 
    worksheet4 = workbook.add_worksheet("PRIORITY_LOTS")
    worksheet5 = workbook.add_worksheet("TARGET_FREQUENCY")

    
  
    #Write indicators in all worksheets
    worksheet1.write('A1', 'Solving_duration') 
    worksheet1.write('B1', 'X_factor') 
    worksheet1.write('C1', 'TargetSatisfaction')
    worksheet1.write('D1', 'Number of moves') 

    worksheet1.write('A1', 'Moves_Window') 
    worksheet2.write('B1', 'X_factor') 
    worksheet2.write('C1', 'TargetSatisfaction')
    worksheet2.write('D1', 'Number of moves') 


    worksheet3.write('A1','Moves')
    worksheet3.write('B1','Cycletime')
    worksheet3.write('C1','TargetSatisfactionIndicator')
    worksheet3.write('D1', 'X_factor') 
    worksheet3.write('E1', 'TargetSatisfaction')
    worksheet3.write('F1', 'Number of moves') 

    worksheet4.write('A1','High_priority')
    worksheet4.write('B1','Medium_priority')
    worksheet4.write('C1','Low_priority')
    worksheet4.write('D1', 'X_factor') 
    worksheet4.write('E1', 'TargetSatisfaction')
    worksheet4.write('F1', 'Number of moves') 


    worksheet5.write('A1','Focus_moves')
    worksheet5.write('B1','Shift_online')
    worksheet5.write('C1', 'X_factor') 
    worksheet5.write('D1', 'TargetSatisfaction')
    worksheet5.write('E1', 'Number of moves') 

    #Close Workbook
    workbook.close() '''


#ExcelTemplate(Code.p)
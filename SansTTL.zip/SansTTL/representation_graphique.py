import os
import glob
import pathlib
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from statistics import mean

def ExcelTemplate():
    """
    Create the template to stock the values the values of each parameter which can be modified for the simulation
    """
    workbook = xlsxwriter.Workbook('DIFFERENCES')
    worksheet1 = workbook.add_worksheet("X_FACTOR")
    worksheet2 = workbook.add_worksheet("MOVES")
    worksheet3 = workbook.add_worksheet("TARGET_SATISFACTION") 
    #Write indicators in all worksheets
    worksheet1.write('A1', 'Data') 
    worksheet1.write('B1', '3-4(TTL)') 
    worksheet1.write('B1', '3-4') 
    worksheet1.write('C1', '4-5(TTL)')
    worksheet1.write('C1', '4-5')
    worksheet1.write('D1', '3-5(TTL)') 
    worksheet1.write('D1', '3-5') 
 
    worksheet2.write('A1', 'Data') 
    worksheet2.write('B1', '3-4') 
    worksheet2.write('C1', '4-5')
    worksheet2.write('D1', '3-5') 

    worksheet3.write('A1', 'Data') 
    worksheet3.write('B1', '3-4') 
    worksheet3.write('C1', '4-5')
    worksheet3.write('D1', '3-5') 

     #Close Workbook
    workbook.close() 
    return workbook



def FindFiles(name):   
    """
    Find path of the file whose name is in parameter
    """
    #Check all the folders in the directory to find 
    source = ""
    path = os.getcwd()
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == name):
            source = filepath
    return source

def fill(name): 
    solving_duration = pd.read_excel(FindFiles(name), sheet_name = 'SOLVING_DURATION_IN_SECONDS')
    list_columns = list(solving_duration.columns.values)
    Solver_data = []
  
    #Get duration 
    duration= list(solving_duration .iloc[:, 0])
    Solver_data.append(duration)

    #Get x_factor
    x_factor = list(solving_duration .iloc[:, 1])
    Solver_data.append(x_factor)

    #Get number of moves
    number_moves  = list(solving_duration .iloc[:, 2])
    Solver_data.append(number_moves)

    #Get target satisfaction
    targetsatisfaction = list(solving_duration .iloc[:, 3])
    Solver_data.append(targetsatisfaction)

    return Solver_data

def trace_compare():
    #Cherche les nos des instances sans les types
    files, names  = [], []
    for f in glob.glob("*.xlsx"):
        files.append(f)
    for i in range(len(files)):
        if(files[i].find('_3_final.xlsx')!= -1):
            j = files[i].strip('_3_final.xlsx')
            names.append(j)
        if (files[i].find('_4_final.xlsx')!= -1):
            k = files[i].strip('_4_final.xlsx')
            names.append(k)
        if(files[i].find('_5_final.xlsx')!= -1 ):
            l = files[i].strip('_5_final.xlsx')
            names.append(l)
            
    Data_names = list(set(names))
    keyDict = set(names)
    names.remove('Solver_20200703_14h4')
    #print(names)
    
    d = dict([(key, []) for key in keyDict])
    #Remplissage du dictionnaire
    for name in names : 
        for f in glob.glob("*.xlsx"):
            if(f.find(name)!= -1):
                d[name] = [fill(name+('_3_final.xlsx')),fill(name+('_4_final.xlsx')),fill(name+('_5_final.xlsx'))]

    X,X_factors3,X_factors4,X_factors5,Number_moves3,Number_moves4,Number_moves5,Target_satisfaction3,Target_satisfaction4,Target_satisfaction5 = [],[],[],[],[],[],[],[],[],[]
    for name in names:
        X.append(d.get(name)[0][0])
        X_factors3.append(d.get(name)[0][1])
        X_factors4.append(d.get(name)[1][1])
        X_factors5.append(d.get(name)[2][1])    

        Number_moves3.append(d.get(name)[0][2])
        Number_moves4.append(d.get(name)[1][2])
        Number_moves5.append(d.get(name)[2][2])

        Target_satisfaction3.append(d.get(name)[0][3])
        Target_satisfaction4.append(d.get(name)[1][3])
        Target_satisfaction5.append(d.get(name)[2][3])
    print(len(X))
      
    for name in names:
    #######################XFactor
        plt.plot(d.get(name)[0][0],  d.get(name)[0][1] , label=name+'3')
        plt.plot(d.get(name)[0][0],  d.get(name)[1][1] , label=name+'4')
        plt.plot(d.get(name)[0][0],  d.get(name)[2][1], label=name+'5')
        plt.xlabel('solving duration in seconds')
        plt.ylabel('x factor')
        plt.title('X factor')
        plt.legend( prop={"size":2})
        ax = plt.subplot(111)
        plt.subplots_adjust(top=0.85)
        box = ax.get_position()
        ax.set_position([box.x0, box.y0, box.width * 0.8, box.height])
        # Put a legend to the right of the current axis
        ax.legend(loc='center left', bbox_to_anchor=(1, 0.5),prop={"size":6})
        plt.savefig('X factor'+ name+'_3_4_5' +'.png')
        plt.show()
    #######################Moves
        plt.plot(d.get(name)[0][0],  d.get(name)[0][2] , label=name+'3') 
        plt.plot(d.get(name)[0][0],  d.get(name)[1][2], label=name+'4') 
        plt.plot(d.get(name)[0][0],  d.get(name)[2][2], label=name+'5') 
        
        plt.xlabel('solving duration in seconds')
        plt.ylabel('moves')
        plt.title('Moves')
        plt.legend( prop={"size":2})
        ax = plt.subplot(111)
        box = ax.get_position()
        ax.set_position([box.x0, box.y0, box.width * 0.8, box.height])
        # Put a legend to the right of the current axis
        ax.legend(loc='center left', bbox_to_anchor=(1, 0.5),prop={"size":6})
        plt.savefig('Moves'+ name+'_3_4_5'+'.png')
        plt.show()
    #######################Target
        plt.plot(d.get(name)[0][0],  d.get(name)[0][3] , label=name+'3')
        plt.plot(d.get(name)[0][0],  d.get(name)[1][3] , label=name+'4')
        plt.plot(d.get(name)[0][0],  d.get(name)[2][3] , label=name+'5') 
        
        plt.xlabel('solving duration in seconds')
        plt.ylabel('target_satisfaction')
        plt.title('Target_satisfaction')
        plt.legend( prop={"size":2})
        ax = plt.subplot(111)
        box = ax.get_position()
        ax.set_position([box.x0, box.y0, box.width * 0.8, box.height])
        # Put a legend to the right of the current axis
        ax.legend(loc='center left', bbox_to_anchor=(1, 0.5),prop={"size":6})
        plt.savefig('Target Satisfaction'+ name +'_3_4_5' +'.png')
        plt.show()




trace_compare()

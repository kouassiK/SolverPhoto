def SelectInputData():
    """
    Select the path to the data's folder
    """
    tkinter.Tk().withdraw()
    path = askdirectory(title='Select folder')
    print(path)
    if os.path.isdir(path):
        dirname = os.path.basename(path)
    return path

def FindModelData():   
    """
    Find ModelData folder path
    """
    #Check all the folders in the directory to find ModelData
    path = os.getcwd()
    for filepath in pathlib.Path(path).glob('*/'): 
        if(filepath.name == "ModelData" ):
            source = filepath
    return source

#def UpdateConfig():
    """
    Launch configuration file and wait until it is closed to start the simulation
    """
def test():
    p1 = SelectInputData()
    fol = os.listdir(p1)
    p2 = FindModelData()

    for i in fol:
        p = os.path.join(p1,i)
        #q = 
        #p3 = 'cp -r ' + p1 +' ' + p2+'/.'
        #sbp.Popen(p3,shell=True)
    print(str(p1))

'''path=input("Enter a path 1: ")
fol = os.listdir(path)
p2 = input("Enter a path 2: ")

for i in fol:
    p1 = os.path.join(path,i)
    p3 = 'cp -r "' + p1 +' ' + p2 
    sbp.Popen(p3,shell=True)'''

#CreateFolders()
#test()
#copy_tree(r'C:\Users\Utilisateur\Desktop\StageSTRousset\Donnés solveur\Solver_20160623_9h\ModelData', r'C:\Users\Utilisateur\Desktop\StageSTRousset\Tests\Logiciels\Project 1.3\Merged')

def CopytreeExistingFolders(src, dst, symlinks= False, ignore = None):
    for item in os.listdir(src):
        s = os.path.join(src, item)
        d = os.path.join(dst, item)
        if os.path.isdir(s):
            shutil.copytree(s,d,symlinks, ignore)
        else:
            shutil.copy2(s,d)


#def FileToFolder():


#copytree(r'C:\Users\Utilisateur\Desktop\StageSTRousset\Tests\Logiciels\Project 1.3\ModelData', r'C:\Users\Utilisateur\Desktop\StageSTRousset\Tests\Logiciels\Project 1.3\input')
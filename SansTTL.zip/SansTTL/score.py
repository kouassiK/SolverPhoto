import os
import pathlib
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import openpyxl
import xlsxwriter
from statistics import *
big_data = []
max_target, min_xFactor, max_moves = 0,0,0

'''ExcelFiles = ['Solver_20160623_16h.xlsx', 'Solver_20160623_17h.xlsx','Solver_20160624_8h.xlsx',
'Solver_20160624_9h.xlsx','Solver_20160627_8h.xlsx', 'Solver_20160627_9h.xlsx' ,'Solver_20160627_10h.xlsx' ,
'Solver_20160627_11h.xlsx' ,'Solver_20160627_12h.xlsx','Solver_20160627_15h.xlsx','Solver_20160627_16h.xlsx']'''

ExcelFiles = ['Solver_20160623_16h.xlsx', 'Solver_20160623_17h.xlsx','Solver_20160624_8h.xlsx','Solver_20160624_9h.xlsx','Solver_20160627_8h.xlsx']
#'''Solver_20160624_9h.xlsx','Solver_20160627_8h.xlsx', 'Solver_20160627_9h.xlsx'''' ]

#ExcelNames = ['Solver_20160623_16h', 'Solver_20160623_17h','Solver_20160624_8h','Solver_20160624_9h','Solver_20160627_8h', 'Solver_20160627_9h' ,'Solver_20160627_10h' ,'Solver_20160627_11h' ,'Solver_20160627_12h','Solver_20160627_15h','Solver_20160627_16h']

def FindFiles(name):   
    """
    Find path of the file whose name is in parameter
    """
    #Check all the folders in the directory to find 
    source = ""
    path = os.getcwd()
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == name):
            source = filepath
    return source

def getX(name):
    '''
    Get the X column of one file 
    '''  
    priority = pd.read_excel(FindFiles(name), sheet_name = 'PRIORITY_LOTS')
    df = pd.DataFrame(priority)
    xFactor_list = list(priority.iloc[:, 3]) 
    return xFactor_list

def getMoves(name):
    '''
    Get the Moves column of one file 
    '''  
    priority = pd.read_excel(FindFiles(name), sheet_name = 'PRIORITY_LOTS')
    df = pd.DataFrame(priority)
    moves_list = list(priority.iloc[:, 4])
    return moves_list

def getTarget(name):
    '''
    Get the target column of one file 
    '''  
    priority = pd.read_excel(FindFiles(name), sheet_name = 'PRIORITY_LOTS')
    df = pd.DataFrame(priority)
    targetsatisfaction_list = list(priority.iloc[:, 5])
    return targetsatisfaction_list
    
def get_final():
    data_x, data_moves,data_target = [],[],[]# contiennent toutes les valeurs des instances
    X1,X2,X3,X4,X5,X6,X7,X8,X9,X10,X11 = [],[],[],[],[],[],[],[],[],[],[]
    M1,M2,M3,M4,M5,M6,M7,M8,M9,M10,M11 = [],[],[],[],[],[],[],[],[],[],[]
    T1,T2,T3,T4,T5,T6,T7,T8,T9,T10,T11 = [],[],[],[],[],[],[],[],[],[],[]
    
    for name in ExcelFiles:
        data_x.append(getX(name))
        data_moves.append(getMoves(name))
        data_target.append(getTarget(name))

    for i in range(5): 
        X1.append(data_x[i][0])
        M1.append(data_moves[i][0])
        T1.append(data_target[i][0])

        X2.append(data_x[i][1])
        M2.append(data_moves[i][1])
        T2.append(data_target[i][1])

        X3.append(data_x[i][2])
        M3.append(data_moves[i][2])
        T3.append(data_target[i][2])
        
        X4.append(data_x[i][3])
        M4.append(data_moves[i][3])
        T4.append(data_target[i][3])

        X5.append(data_x[i][4])
        M5.append(data_moves[i][4])
        T5.append(data_target[i][4])

        X6.append(data_x[i][5])
        M6.append(data_moves[i][5])
        T6.append(data_target[i][5])

        X7.append(data_x[i][6])
        M7.append(data_moves[i][6])
        T7.append(data_target[i][6])

        X8.append(data_x[i][7])
        M8.append(data_moves[i][7])
        T8.append(data_target[i][7])

        X9.append(data_x[i][8])
        M9.append(data_moves[i][8])
        T9.append(data_target[i][8])

        X10.append(data_x[i][9])
        M10.append(data_moves[i][9])
        T10.append(data_target[i][9])

        X11.append(data_x[i][10])
        M11.append(data_moves[i][10])
        T11.append(data_target[i][10])

         
    l1 = [median(X1), median(X2), median(X3) ,median(X4), median(X5), median(X6), median(X7), median(X8), median(X9), median(X10), median(X11)] 
    l2 = [median(M1), median(M2), median(M3) ,median(M4), median(M5), median(M6), median(M7), median(M8), median(M9), median(M10), median(M11)] 
    l3 =  [median(T1), median(T2), median(T3), median(T4), median(T5), median(T6), median(T7), median(T8), median(T9), median(T10), median(T11)] 

    l4 = [mean(X1), mean(X2), mean(X3), mean(X4), mean(X5), mean(X6), mean(X7), mean(X8), mean(X9), mean(X10), mean(X11)] 
    l5 = [mean(M1), mean(M2), mean(M3), mean(M4), mean(M5), mean(M6), mean(M7), mean(M8), mean(M9), mean(M10), mean(M11)] 
    l6 =  [mean(T1), mean(T2), mean(T3), mean(T4), mean(T5), mean(T6), mean(T7), mean(T8), mean(T9), mean(T10), mean(T11)]

    vecteurs = ['(1,0,0)', '(1,0.5,0.1)' ,'(1,1,1)' ,
    '(5,1,1)' ,'(5,2,1)', '(10,1,1)',
    '(10,2,1)', '(10,5,1)' ,'(50,20,1)' , 
    '(100, 10, 1)', '(100, 50, 1)']

##--------------------------------------------------------------Devs X--------------------------------------------------------------------------
    x_pos = np.arange(len(vecteurs))
    X_devs = [stdev(X1), stdev(X2), stdev(X3), stdev(X4) ,stdev(X5), stdev(X6), stdev(X7), stdev(X8), stdev(X9), stdev(X10), stdev(X11)]
    bests_X = [min(X1), min(X2), min(X3), min(X4) ,min(X5), min(X6), min(X7), min(X8), min(X9), min(X10), min(X11)]
    #print(bests_X)

    # Build the plot
    fig, ax = plt.subplots()
    ax.bar(x_pos, bests_X, yerr=X_devs, align='center', alpha=0.5, ecolor='black', capsize=5)
    ax.set_ylabel('X Factor')
    ax.set_xticks(x_pos)
    ax.set_xticklabels(vecteurs)
    ax.set_title('Paramètres lot_priority')
    ax.yaxis.grid(True)

    # Save the figure and show
    plt.tight_layout()
    plt.savefig('Deviation XFactor pour tous les extracts .png')
    plt.show()

#-------------------------------------------------------------Devs Moves--------------------------------------------------------------

    x_pos = np.arange(len(vecteurs))
    Moves_devs = [stdev(M1), stdev(M2), stdev(M3), stdev(M4) ,stdev(M5), stdev(M6), stdev(M7), stdev(M8), stdev(M9), stdev(M10), stdev(M11)]
    bests_Moves = [max(M1), max(M2), max(M3), max(M4) ,max(M5), max(M6), max(M7), max(M8), max(M9), max(M10), max(M11)]
    

    # Build the plot
    fig, ax = plt.subplots()
    #ax.errorbar(x_pos, bests_Moves, yerr=Moves_devs, alpha=0.5, ecolor='black', capsize=5)
    ax.errorbar(x_pos, bests_Moves, yerr=Moves_devs, fmt='o',color='orange', capsize=5)
    ax.set_ylabel('Moves')
    ax.set_xticks(x_pos)
    ax.set_xticklabels(vecteurs)
    ax.set_title('Paramètres lot_priority')
    ax.yaxis.grid(True)

    # Save the figure and show
    plt.tight_layout()
    plt.savefig('Deviation Moves pour tous les extracts .png')
    plt.show()

    #----------------------------------------------------------------------Devs Target Satisfaction--------------------------------------------------

    x_pos = np.arange(len(vecteurs))
    Target_devs = [stdev(T1), stdev(T2), stdev(T3), stdev(T4) ,stdev(T5), stdev(T6), stdev(T7), stdev(T8), stdev(T9), stdev(T10), stdev(T11)]
    bests_target = [max(T1), max(T2), max(T3), max(T4) ,max(T5), max(T6), max(T7), max(T8), max(T9), max(T10), max(T11)]
    #print(bests_X)

    # Build the plot
    fig, ax = plt.subplots()
    ax.bar(x_pos, bests_target, yerr=Target_devs, align='center', alpha=0.5, ecolor='black', capsize=5)
    ax.set_ylabel('Target Satisfaction')
    ax.set_xticks(x_pos)
    ax.set_xticklabels(vecteurs)
    ax.set_title('Paramètres lot_priority')
    ax.yaxis.grid(True)

    # Save the figure and show
    plt.tight_layout()
    plt.savefig('DeviationXFactor pour tous les extracts .png')
    plt.show()


    workbook = xlsxwriter.Workbook("PriorityResults.xlsx")
    worksheet1 = workbook.add_worksheet("Median")
    worksheet1.write('A1', 'Weights') 
    worksheet1.write('B1', 'MedianX') 
    worksheet1.write('C1', 'MedianMoves') 
    worksheet1.write('D1', 'MedianTarget') 

     
    worksheet2 = workbook.add_worksheet("Mean")
    worksheet2.write('A1', 'Weights') 
    worksheet2.write('B1', 'MeanX') 
    worksheet2.write('C1', 'MeanMoves') 
    worksheet2.write('D1', 'MeanTarget') 

    for i in range(1,len(vecteurs)+1): #11 valeurs de vecteurs
        worksheet1.write(i,0,vecteurs[i-1]) 
        worksheet1.write(i,1,l1[i-1]) 
        worksheet1.write(i,2,l2[i-1]) 
        worksheet1.write(i,3,l3[i-1]) 

        worksheet2.write(i,0,vecteurs[i-1]) 
        worksheet2.write(i,1,l4[i-1]) 
        worksheet2.write(i,2,l5[i-1]) 
        worksheet2.write(i,3,l6[i-1]) 
    workbook.close()



def fill_deviation(name):
    global  max_target, min_xFactor, max_moves
    priority = pd.read_excel(FindFiles(name), sheet_name = 'PRIORITY_LOTS')
    df = pd.DataFrame(priority)
    #Get max target satisfaction
    targetsatisfaction_list = list(priority.iloc[:, 5])
    max_target = max(targetsatisfaction_list)
    index_max_target = targetsatisfaction_list.index(max(targetsatisfaction_list))
    l1 = [df.loc[index_max_target,:][0], df.loc[index_max_target,:][1],df.loc[index_max_target,:][2],max(targetsatisfaction_list)]
    #Get min x factor
    xFactor_list = list(priority.iloc[:, 3])
    min_xFactor = min(xFactor_list)
    indice_min_xFactor = xFactor_list.index(min(xFactor_list))
    l2 = [df.loc[indice_min_xFactor,:][0], df.loc[indice_min_xFactor,:][1],df.loc[indice_min_xFactor,:][2],min(xFactor_list)]
    #Get max moves
    moves_list = list(priority.iloc[:, 4])
    max_moves = max(moves_list)
    index_max_moves = moves_list.index(max(moves_list))
    l3 = [df.loc[index_max_moves,:][0], df.loc[index_max_moves,:][1],df.loc[index_max_moves,:][2],max(moves_list)]
    

    vecteurs = ['(1,0,0)', '(1,0.5,0.1)' ,'(1,1,1)' ,
    '(5,1,1)' ,'(5,2,1)', '(10,1,1)',
    '(10,2,1)', '(10,5,1)' ,'(50,20,1)' , 
    '(100, 10, 1)', '(100, 50, 1)']

    workbook = xlsxwriter.Workbook(name + "Deviation.xlsx")
    worksheet = workbook.add_worksheet(name)
    worksheet.write('A1', 'Instance+ Vecteur') 
    worksheet.write('B1', 'DeviationXFactor') 
    worksheet.write('C1', 'DeviationMoves') 
    worksheet.write('D1', 'DeviationTargetSatisfaction') 

    for i in range(1,len(vecteurs)+1):
        worksheet.write(i, 0, name + '' + vecteurs[i-1])
        worksheet.write(i, 1,(xFactor_list[i-1]- min_xFactor) / min_xFactor) #X
        worksheet.write(i, 2,(max_moves - moves_list[i-1]) /  max_moves)#Moves
        worksheet.write(i, 3 ,(max_target -  targetsatisfaction_list[i-1])/ max_target) #Target


    workbook.close()
    best_results = [min_xFactor, max_moves, max_target]
    #big_data.append(data)
    #return data


#Test
for name in ExcelFiles:
    fill_deviation(name)

get_final()


'''def std_X(name):
    X = getX(name)  
    X_std = np.std(X)# Calculate the standard deviation
    x_pos = np.arange(len(vectors))
    best_results = fill_deviation(name)#on récupère résultats
    best_results[0] = 
    error = [X_std, Moves_std, Target_std]'''
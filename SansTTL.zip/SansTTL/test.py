import xml.etree.ElementTree as ET
from xml.etree import ElementTree
import openpyxl
import xlsxwriter
import pathlib
import shutil
import xlrd
import copy
import os

'''def ExcelTemplate(name):
    """
    Create the template to stock the values the values of each parameter which can be modified for the simulation
    """
    #Excel file creation
    #name = Code.SelectInputData()

    workbook = xlsxwriter.Workbook(name)
    worksheet1 = workbook.add_worksheet("SOLVING_DURATION_IN_MINUTES")
    worksheet2 = workbook.add_worksheet("MOVES_WINDOW_IN_HOURS")
    worksheet3 = workbook.add_worksheet("MULTICRITERIA_MODE") 
    worksheet4 = workbook.add_worksheet("PRIORITY_LOTS")
    worksheet5 = workbook.add_worksheet("TARGET_FREQUENCY")

    #Write indicators in all worksheets
    worksheet1.write('A1', 'Solving_duration') 
    worksheet1.write('B1', 'X_factor') 
    worksheet1.write('C1', 'TargetSatisfaction')
    worksheet1.write('D1', 'Number of moves') 

    worksheet2.write('A1', 'Moves_Window') 
    worksheet2.write('B1', 'X_factor') 
    worksheet2.write('C1', 'TargetSatisfaction')
    worksheet2.write('D1', 'Number of moves') 

    worksheet3.write('A1','Moves')
    worksheet3.write('B1','Cycletime')
    worksheet3.write('C1','TargetSatisfactionIndicator')
    worksheet3.write('D1', 'X_factor') 
    worksheet3.write('E1', 'TargetSatisfaction')
    worksheet3.write('F1', 'Number of moves') 

    worksheet4.write('A1','High_priority')
    worksheet4.write('B1','Medium_priority')
    worksheet4.write('C1','Low_priority')
    worksheet4.write('D1', 'X_factor') 
    worksheet4.write('E1', 'TargetSatisfaction')
    worksheet4.write('F1', 'Number of moves') 

    worksheet5.write('A1','Focus_moves')
    worksheet5.write('B1','Shift_online')
    worksheet5.write('C1', 'X_factor') 
    worksheet5.write('D1', 'TargetSatisfaction')
    worksheet5.write('E1', 'Number of moves') 

    #Close Workbook
    workbook.close() 
    return workbook

def ExistsExcel(ExcelFile):
    """
    Return True if an Excel file of the selected zip already exists
    Return False otherwise
    """
    exists = False
    path = os.getcwd()
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == ExcelFile):
            exists = True
            return exists
        else:
            exists = False
    return exists


def Edit(ExcelFileName):
    workbook = openpyxl.load_workbook(ExcelFileName) 
    worksheet0 = workbook.worksheets[0]
    row = worksheet0.max_row
    worksheet0.cell(row + 1, 1).value = 456
    workbook.save(ExcelFileName)



def Write(ExcelFileName):
    if(ExistsExcel(ExcelFileName) == True):  
        Edit(ExcelFileName)

    if(ExistsExcel(ExcelFileName) == False):
        ExcelTemplate(ExcelFileName) 
        Edit(ExcelFileName)
        

def NewData(ExcelFile):
    """
    Return True if an Excel file of the selected zip already exists
    Return False otherwise
    """
    exists = False
    path = os.getcwd()
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == ExcelFile):
            exists = True
            return exists
        else:
            exists = False
    return exists


def Excel(name,ParametersValues, ResultValues):
    """
    Create template or complete existing Excel file to save parameters and simulation indicators
    """
    if(NewData(name) == False): 
        """
        Create the template to stock the values the values of each parameter which can be modified for the simulation
        """
        #Excel file creation
        #name = Code.SelectInputData()
        global worbook
        global worksheet1
        global worksheet2
        global worksheet3
        global worksheet4
        global worksheet5

        workbook = xlsxwriter.Workbook(name + '.xlsx')

        worksheet1 = workbook.add_worksheet("SOLVING_DURATION_IN_MINUTES")
        worksheet2 = workbook.add_worksheet("MOVES_WINDOW_IN_HOURS")
        worksheet3 = workbook.add_worksheet("MULTICRITERIA_MODE") 
        worksheet4 = workbook.add_worksheet("PRIORITY_LOTS")
        worksheet5 = workbook.add_worksheet("TARGET_FREQUENCY")  
    
        #Write indicators in all worksheets
        worksheet1.write('A1', 'Solving_duration') 
        worksheet1.write('B1', 'X_factor') 
        worksheet1.write('C1', 'TargetSatisfaction')
        worksheet1.write('D1', 'Number of moves') 

        worksheet2.write('A1', 'Moves_Window') 
        worksheet2.write('B1', 'X_factor') 
        worksheet2.write('C1', 'TargetSatisfaction')
        worksheet2.write('D1', 'Number of moves') 

        worksheet3.write('A1','Moves')
        worksheet3.write('B1','Cycletime')
        worksheet3.write('C1','TargetSatisfactionIndicator')
        worksheet3.write('D1', 'X_factor') 
        worksheet3.write('E1', 'TargetSatisfaction')
        worksheet3.write('F1', 'Number of moves') 

        worksheet4.write('A1','High_priority')
        worksheet4.write('B1','Medium_priority')
        worksheet4.write('C1','Low_priority')
        worksheet4.write('D1', 'X_factor') 
        worksheet4.write('E1', 'TargetSatisfaction')
        worksheet4.write('F1', 'Number of moves') 

        worksheet5.write('A1','Focus_moves')
        worksheet5.write('B1','Shift_online')
        worksheet5.write('C1', 'X_factor') 
        worksheet5.write('D1', 'TargetSatisfaction')
        worksheet5.write('E1', 'Number of moves') 

        #Write values of the new parameters
        worksheet1.write()
    

    
    #The Excel file already exists(one or several simulations have been run)
    if(NewData(name) == True):

    



    #Close Workbook
        workbook.close()
#def ExcelSave():
    """
    Save the results of the simulation in Excel file
    """
'''

def FindSolutionPath():
    """
    Find the name path of file
    """
    path = os.getcwd()
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == "Solution.xml"):
            found = filepath
    return found

def GetNumberMasksTransfers():
    """
    Get the number of masks transfer

    """
    with open('Solution.xml', 'rt') as f:
        tree = ElementTree.parse(f)
    number_masks_transfers = 0
    for node in tree.iter():
        if(node.tag == "OutputMaskTransfer"):
            number_masks_transfers = number_masks_transfers + 1 
            
    print(number_masks_transfers)
    return number_masks_transfers


def GetNumberTemperatureChanges():
    """
    Get the number of changing temperatures 

    """
    with open('Solution.xml', 'rt') as f:
        tree = ElementTree.parse(f)
    number_temperature_change = 0
    for node in tree.iter():
        if(node.tag == "OutputChangeover"):
            number_temperature_change = number_temperature_change  + 1 
            
    print(number_temperature_change)
    return number_temperature_change
        
def SaveValues(filepath):
    """
    Get the values of the indicators in Solution.xml
    
    """
    tree = ET.parse(filepath.name)
    #print(filepath.name)
    root = tree.getroot()
    #Recuperate results
    result = []
    xFactor = float(root[1][2].text)
    numberOfMoves = float(root[1][0].text)
    targetSatisfactionIndicator = float(root[1][1].text)
    result = [xFactor, numberOfMoves, targetSatisfactionIndicator,GetNumberMasksTransfers(), GetNumberTemperatureChanges()]
    
    #Conversion des paramètres
    print(result)
    return result

'''def MaskTransfers():
    """
    Get the values of the number of masks transfers in Solution.xml
    
    """
    tree = ET.parse(filepath.name)
    #print(filepath.name)
    root = tree.getroot()
    #Recuperate results
    result = 0
    weightedWaitingRatio = float(root[1][1].text)
    totalScore = float(root[1][8].text)
    overallTargetSatisfaction = float(root[1][9].text)
    result = [weightedWaitingRatio, totalScore, overallTargetSatisfaction]'''

#SaveValues(FindSolutionPath())

def MoveSolution():
    """
    Return True if an Excel file of the selected zip already exists
    Return False otherwise
    """
    exists = False
    path = os.getcwd()
    print(path)
    for filepath in pathlib.Path(path).glob('**/*'): 
        #print(filepath.name)
        if(filepath.name == "Solution.xml"):
            print(filepath, path)
            real_dst = os.path.join(path, os.path.basename(filepath))
            shutil.move(filepath,real_dst)
            
def MoveModelData():
    """
    Move the ModelData folder to the input folder
    """
    path = os.getcwd()
    model_data = os.path.join(path,r'ModelData')
    for filepath in pathlib.Path(path).glob('*/'): 
        if(filepath.name == "input" ):
            shutil.move(model_data ,filepath)

def MoveBackModelData():
    path = os.getcwd()
    print(path)
    for filepath in pathlib.Path(path).glob('*/*'): 
        #print(filepath.name)
        if(filepath.name == "ModelData"):
            print(filepath, path)
            real_dst = os.path.join(path, os.path.basename(filepath))
            shutil.move(filepath,real_dst)

MoveModelData()         
MoveBackModelData()

#ExistsExcel()
#print(FindSolutionPath())
#SaveValues(r'C:\Users\Utilisateur\Desktop\StageSTRousset\Tests\Logiciels\Project 1.3\output\Solution.xml')
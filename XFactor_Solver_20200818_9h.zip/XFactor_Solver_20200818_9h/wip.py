import os
import glob
import pathlib
import openpyxl 
import xlsxwriter
import collections
import datetime
import statistics
from collections import OrderedDict
import xml.etree.ElementTree as ET
import math


def DateInitiale():
    origin = ""
    path = os.getcwd()
    for filepath in pathlib.Path(path).glob('**/*'): 
        #print(filepath.name)
        if(filepath.name == "ToolStatuses.txt"):
            f = open(filepath,'r')
            lines = f.readlines()
            line = lines[1] #Get the second line
            t = line.split(';') #get table of value separated by semi colon
            origin = t[4]
            start = True
            f.close()
    date = origin[11:]
    #print(date)
    return origin.strip('\n')

#Fraction des dates en une journée
def FractionIdeal():
    date_time_obj = datetime.datetime.strptime(DateInitiale(), '%Y-%m-%d %H:%M:%S')
    t = date_time_obj.time()
    h = int(t.hour)
    m = int(t.minute)
    s = int(t.second)
    hours = datetime.time(h,0,0)
    a = datetime.timedelta(0, (h*3600+m*60+s))
    b = datetime.timedelta(0, (6*3600+0*60+0)) #h pour début de journée
    c = datetime.timedelta(0, (2*3600+0*60+0)) #2h pour l'horizon
    d = (abs(a-b)/24 ).total_seconds()
    e = (abs(a + c -b)/24 ).total_seconds()
    dates = [d/3600, e/3600 ] #[Ideal t0 fraction, Ideal t+2h fraction]
    print(dates)
    return dates

#To get the list of the ProductionID (lattices codes)
def lattice_codes(nameXml):
    lattice_codes = []
    tree = ET.parse(nameXml)
    root = tree.getroot()
    keys = list(root[5][0].attrib.keys())  
    line = []
    
    for i in range(len(root[5])):  
        lattice_codes.append(root[5][i].get('ProductionTargetID'))
    #print(lattice_codes)
    return lattice_codes

#Wip
def  Wip(nameXml):
    name = "Lots.txt"
    path = os.getcwd()
    lines = []
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == name ):
            f = open(filepath,'r')
            c = len(open(filepath).readlines( ))
    for i in range(c):
        line = f.readline()
        t = line.split(';')
        lines.append(t)

    lots_wafers = [] #Dans Lots.txt
    for i in range(1,len(lines)):
        code = lines[i][1]
        latticeID = code[:-5]  
        lots_wafers.append([latticeID, lines[i][3]])

    
    
    data = dict([(key, []) for key in lattice_codes(nameXml)])
    result = dict([(key, 0) for key in lattice_codes(nameXml)])
    for i in range(len(lots_wafers)):
        if(lots_wafers[i][0] in data.keys()):
            data[lots_wafers[i][0]].append(int(lots_wafers[i][1]))

    for k in data.keys():
        result[k] = str(sum(data[k]))

    '''for k,v in result.items():
        print(k,v)'''
    return result

#%Proposed
def scheduled(nameXml):
    scheduled = []
    tree = ET.parse(nameXml)
    root = tree.getroot()
    keys = list(root[5][0].attrib.keys())  
    line = []
    lattices_codes = lattice_codes(nameXml)
    for i in range(len(root[5])):  
        line.append([root[5][i].get('ProductionTargetID'),root[5][i].get('TargetVolume'),root[5][i].get('InitialVolume'), root[5][i].get('FrozenVolume'),root[5][i].get('ScheduledVolume')])
    for i in range(len(line)):
        if(line[i][0] in lattices_codes):
            scheduled_volume = float(line[i][4])
            target_volume = float(line[i][1])
            scheduled.append((scheduled_volume / target_volume)*100)
    #print(len(scheduled))
    return scheduled

#%Initial
def initialVolume_list(nameXml):
    lattices_codes = lattice_codes(nameXml)
    initialVolume_list = []
    tree = ET.parse(nameXml)
    root = tree.getroot()
    keys = list(root[5][0].attrib.keys())  
    line = []
    for i in range(len(root[5])):      
        line.append([root[5][i].get('ProductionTargetID'),root[5][i].get('TargetVolume'),root[5][i].get('InitialVolume'), root[5][i].get('FrozenVolume'),root[5][i].get('ScheduledVolume')])

    for i in range(len(line)):
        if(line[i][0] in lattices_codes):
            initial_volume = float(line[i][2])
            target_volume = float(line[i][1])
            #Pour le graphe
            initialVolume_list.append((initial_volume / target_volume)*100)
    return initialVolume_list

#Target Initial et Proposed
def parse_solution(nameXml):
    lattices_codes = lattice_codes(nameXml)
    tree = ET.parse(nameXml)
    root = tree.getroot()
    keys = list(root[5][0].attrib.keys())  
    line = []
    
    for i in range(len(root[5])):      
        line.append([root[5][i].get('ProductionTargetID'),root[5][i].get('TargetVolume'),root[5][i].get('InitialVolume'), root[5][i].get('FrozenVolume'),root[5][i].get('ScheduledVolume')])

    data = dict([(key, 0) for key in lattices_codes])
    result = dict([(key, 0) for key in lattices_codes]) 

    for i in range(len(line)):
        if(line[i][0] in lattices_codes):
            initial_volume = float(line[i][2])
            scheduled_volume = float(line[i][4])
            target_volume = float(line[i][1])
            tableau = []
            tableau.append(initial_volume) #volume Initial
            tableau.append(scheduled_volume)# volume Proposed
            tableau.append(target_volume) #volume Target

            tableau.append((initial_volume/target_volume)*100)
            tableau.append(((scheduled_volume + initial_volume)/target_volume)*100)
            data[line[i][0]] = tableau
    '''for k,v in data.items():
        print(k,v)'''
    
    return data


def Excel(nameXml, data):
    workbook = xlsxwriter.Workbook('Equilibrages_targets_'+ (nameXml.strip('.xml')) +'.xlsx')
    worksheet = workbook.add_worksheet()
    d1 = DateInitiale()[11:]
    #d2 = str(Date())'''
    #Write indicators in all worksheets
    worksheet.write('A1', "06:00")
    worksheet.write('D1', d1)
    h = int(d1[0:2]) + 2
    worksheet.write('E1', str(h) + d1[2:])

    worksheet.write('A2', 'TargetID ') 
    worksheet.write('B2', 'Target')
    worksheet.write('C2', 'WIP')
    worksheet.write('D2', 'Initial')
    worksheet.write('E2', 'Proposed')
    worksheet.write('G2', 'Ideal t0')
    worksheet.write('H2', 'Comportement attendu')
    worksheet.write('J2', 'Init+Proposed')
    worksheet.write('K2', 'Ideal t+2h')
    worksheet.write('M2', '%Initial')
    worksheet.write('N2', '%Proposed')
    worksheet.write('O2', '%Potentiel')
    worksheet.write('P2', '%Ideal')
    j = 2
    codes = lattice_codes(nameXml)
    initialVolume = initialVolume_list(nameXml)

    for i in range(len(data)):
        worksheet.write(j, 0, codes[i]) #TargetID
        worksheet.write(j, 1, data.get(codes[i])[2])#Target
        worksheet.write(j, 2, Wip(nameXml).get(codes[i])) #WIP
        worksheet.write(j, 3, data.get(codes[i])[0])#Initial
        worksheet.write(j, 4, data.get(codes[i])[1])#Proposed
        worksheet.write(j, 6, FractionIdeal()[0] *   data.get(codes[i])[2])#Ideal t0
        worksheet.write(j, 10, FractionIdeal()[1] *   data.get(codes[i])[2] )#Ideal t+2h
        worksheet.write(j, 14, float("{:.2f}".format(100*abs((data.get(codes[i])[0] - data.get(codes[i])[1]) / data.get(codes[i])[2]))) ) #%Potentiel
        worksheet.write(j, 15, float("{:.2f}".format(100*FractionIdeal()[1]))) #%Ideal

        if(FractionIdeal()[0] *   data.get(codes[i])[2] -  data.get(codes[i])[0] < -100): #Comportement attendu
            worksheet.write(j, 7, -2)
        if(FractionIdeal()[0] *   data.get(codes[i])[2] -  data.get(codes[i])[0] < -50): #Comportement attendu
            worksheet.write(j, 7, -1)
        if(FractionIdeal()[0] *   data.get(codes[i])[2] -  data.get(codes[i])[0] > 100): #Comportement attendu
            worksheet.write(j, 7, 2)
        if(FractionIdeal()[0] *   data.get(codes[i])[2] -  data.get(codes[i])[0] > 50): #Comportement attendu
            worksheet.write(j, 7, 1)
        
        else:
            worksheet.write(j, 7, 0)

        worksheet.write(j, 9, data.get(codes[i])[0] + data.get(codes[i])[1] ) #Init + Proposed
        j = j + 1

    #Pour le  graphe 
    s = scheduled(nameXml)
    k = 2
    for i in range(len(initialVolume)):
        a = float("{:.2f}".format(initialVolume[i]))
        b = float("{:.2f}".format(s[i]))
        worksheet.write(k, 12, a)#%Initial
        worksheet.write(k, 13, b)#%Proposed
        k = k + 1
    workbook.close() 
    return workbook


def ExistsXml():
    path = os.getcwd()
    filesnames = []
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name.find('.xml')!=-1 and filepath.name.find('[')!=-1):
            filesnames.append(filepath.name) 
    return filesnames
             
fichiers = ExistsXml()
for i in range(len(fichiers)):
    Excel(fichiers[i], parse_solution(fichiers[i]))



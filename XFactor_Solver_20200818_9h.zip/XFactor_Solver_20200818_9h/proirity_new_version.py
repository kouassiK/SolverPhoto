import os
import glob
import pathlib
import pandas as pd
import openpyxl 
import xlsxwriter
import datetime
import dateutil.parser
import xml.etree.ElementTree as ET

############################################# Within Horizon ########################################

def parse_within_horizon_list(nameXml):
    '''
    Retourne toutes les données du noeud within horizon list
    '''
    tree = ET.parse(nameXml)
    root = tree.getroot()
    list_within_horizon = [] 
    for i in range(len(root[4])):
        list_within_horizon.append([root[4][i].get('LotID'), root[4][i].get('PriorityClass'), root[4][i].get('StartDateTime'), root[4][i].get('EndDateTime')] )
    #print(list_within_horizon)
    return list_within_horizon

def High_within(listWithin):
    '''
    Liste High dans within
    '''
    High_list = []
    for i in range(len(listWithin)):
        if(listWithin[i][1] == ' High_PIT'):
            High_list.append(listWithin[i][0])
    #print(High_list)
    return High_list
  
def Standard_within(listWithin):
    '''
    Liste Standard dans within
    '''
    Standard_list = []
    for i in range(len(listWithin)):
        if(listWithin[i][1] == ' Standard_PIT'):
            Standard_list.append(listWithin[i][0])
    #print(Standard_list)
    return Standard_list

def Customer_within(listWithin):
    '''
    Liste Customer dans within
    '''
    Customer_list = []
    for i in range(len(listWithin)):
        if(listWithin[i][1] == ' Customer_PIT'):
            Customer_list.append(listWithin[i][0])
    #print(Customer_list)
    return Customer_list


###############################################Liste complète#####################################
def parse_complete_list(nameXml):
    '''
    Retourne les infos du noeud complet
    '''
    tree = ET.parse(nameXml)
    root = tree.getroot()
    list_complete = [] 
    for i in range(len(root[8])):
        list_complete.append([root[8][i].get('LotID'), root[8][i].get('PriorityClass'), root[8][i].get('StartDateTime'), root[8][i].get('EndDateTime')] )
    #print(list_complete)
    return list_complete

def High_complete(listComplete):
    '''
    Liste High dans complete
    '''
    Highs = []
    for i in range(len(listComplete)):
        if(listComplete[i][1] == ' High_PIT'):
            Highs.append(listComplete[i][0])
    #print(Highs)
    return Highs

def Standard_complete(listComplete):
    '''
    Liste Standard dans complete
    '''
    Standards = []
    for i in range(len(listComplete)):
        if(listComplete[i][1] == ' Standard_PIT'):
            Standards.append(listComplete[i][0])
    #print(len(Standards))
    return Standards

def Customer_complete(listComplete):
    '''
    Liste Customer dans complete
    '''
    Customers = []
    for i in range(len(listComplete)):
        if(listComplete[i][1] == ' Customer_PIT'):
            Customers.append(listComplete[i][0])
    #print(Customers)
    return Customers

   
def percentages(nameXml):
    ####################################### complete ##################################
    complete = parse_complete_list(nameXml)

    high_complete = High_complete(complete)
    standard_complete = Standard_complete(complete)
    customer_complete = Customer_complete(complete)

    total_high_complete = len(High_complete(complete))
    total_standard_complete = len(Standard_complete(complete))
    total_customer_complete = len(Customer_complete(complete))

    ################################### within ##################################
    within = parse_within_horizon_list(nameXml)
    total_high_within = len(High_within(within))
    total_standard_within = len(Standard_within(within))
    total_customer_within = len(Customer_within(within))

    final = {'HIGH_PIT' : 100*(total_high_within / total_high_complete),  
            'STANDARD_PIT': 100*(total_standard_within / total_standard_complete), 
            'CUSTOMER_PIT' : 100*(total_customer_within / total_customer_complete) }

    name  = nameXml.strip('.xml') +'.txt'
    fichier = open('pourcentages_lots_'+name, "a") 
    fichier.write(nameXml +'\n')
    fichier.write('high : ' + str(total_high_within) + '/' + str(total_high_complete) +'\n' )
    fichier.write('standard : '  + str(total_standard_within) + '/' + str(total_standard_complete) +'\n')
    fichier.write('customer : ' + str(total_customer_within) + '/' + str(total_customer_complete) +'\n' )
    fichier.write('\n')
    fichier.close() 

    return final


def ExcelTemplate():      
    workbook = xlsxwriter.Workbook('FinalResults.xlsx') 
    worksheet = workbook.add_worksheet() 
    worksheet.write('A1', 'Parameters ')
    worksheet.write('B1', 'High priority % ') 
    worksheet.write('C1', 'Standard priority % ') 
    worksheet.write('D1', 'Customer priority %')
    #worksheet.write('E1', 'High hours ') 
    #worksheet.write('F1', 'Standard hours') 
    #worksheet.write('G1', 'Customer hours ')

    worksheet.write(1, 0, "(1,1,1)") #1
    worksheet.write(2, 0, "(2,1,0.5)" ) #2
    worksheet.write(3, 0, "(3,1,0.5)") #3
    worksheet.write(4, 0, "(3,1,1)") #4
    worksheet.write(5, 0,"(8,2,1)" ) #5
    worksheet.write(6, 0, "(10,4,2)") #6
    worksheet.write(7, 0, "(20,2,1)") #7
    worksheet.write(8, 0,"(100,0.1,0.01)" ) #8
    worksheet.write(9, 0,"(1000,20,1)" ) #9
    worksheet.write(10, 0,"(1000,100,10)" ) #10

    workbook.close()


def Edit(longname):
    name = longname.split('h_')[0]
    parameters = (longname.strip('.xml')).split('h_')[1]
    i = 0
    #print(parameters)
    workbook = openpyxl.load_workbook('FinalResults.xlsx') 
    l = workbook.sheetnames
    if name in l: # Excel existe et la feuille existe déjà
        worksheet = workbook[name]
        if(parameters.find("1_1_1")!= -1): 
            i = 2
        if(parameters.find("2_1_0.5")!= -1):
            i = 3
        if(parameters.find("3_1_0.5")!= -1):
            i = 4     
        if(parameters.find("3_1_1")!= -1):
            i = 5 
        if(parameters.find("8_2_1")!= -1):
            i = 6
        if(parameters.find("10_4_2")!= -1):
            i = 7
        if(parameters.find("20_2_1")!= -1):
            i = 8
        if(parameters.find("100_0.1_0.01")!= -1):
            i = 9
        if(parameters.find("1000_20_1")!= -1):
            i = 10
        if(parameters.find("1000_100_10")!= -1):
            i = 11

        data = percentages(longname)
        worksheet.cell(i,2).value = data.get('HIGH_PIT')
        worksheet.cell(i,3).value = data.get('STANDARD_PIT')
        worksheet.cell(i,4).value = data.get('CUSTOMER_PIT')
        

    workbook.save("FinalResults.xlsx")
    j = 0
    if name not in l: # Excel existe et la feuille n'existe pas 
        #on crée la feuille
        worksheet = workbook.create_sheet(name)
        worksheet.cell(1,1).value =  'Parameters '
        worksheet.cell(1,2).value = 'High priority % '
        worksheet.cell(1,3).value = 'Standard priority % ' 
        worksheet.cell(1,4).value =  'Customer priority %'

        worksheet.cell(2, 1).value =  "(1,1,1)" #1
        worksheet.cell(3, 1).value =  "(2,1,0.5)"  #2
        worksheet.cell(4, 1).value =  "(3,1,0.5)"  #3
        worksheet.cell(5, 1).value =  "(3,1,1)"  #4
        worksheet.cell(6, 1).value = "(8,2,1)"  #5
        worksheet.cell(7, 1).value = "(10,4,2)" #6
        worksheet.cell(8, 1).value = "(20,2,1)"  #7
        worksheet.cell(9, 1).value = "(100,0.1,0.01)"  #8
        worksheet.cell(10, 1).value = "(1000,20,1)"  #9
        worksheet.cell(11, 1).value = "(1000,100,10)"  #10
        
        #on trouve sa ligne
        if(parameters.find("1_1_1")!= -1): 
            j = 2
        if(parameters.find("2_1_0.5")!= -1):
            j = 3
        if(parameters.find("3_1_0.5")!= -1):
            j = 4
        if(parameters.find("3_1_1")!= -1):
            j = 5 
        if(parameters.find("8_2_1")!= -1):
            j = 6
        if(parameters.find("10_4_2")!= -1):
            j = 7
        if(parameters.find("20_2_1")!= -1):
            j = 8
        if(parameters.find("100_0.1_0.01")!= -1):
            j = 9 
        if(parameters.find("1000_20_1")!= -1):
            j = 10   
        if(parameters.find("1000_100_10")!= -1):
            j = 11
        #on remplit
        donnees = percentages(longname)
        worksheet.cell(j,2).value = donnees.get('HIGH_PIT')
        worksheet.cell(j,3).value = donnees.get('STANDARD_PIT')
        worksheet.cell(j,4).value = donnees.get('CUSTOMER_PIT')

    workbook.save('FinalResults.xlsx')

def ExistsXlsx():
    filesnames = []
    path = os.getcwd()
    value = False
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == "FinalResults.xlsx"):
            value = True
    return value 

def ExistsXml():
    filesnames = []
    path = os.getcwd()
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name.find('.xml')!=-1 and filepath.name.find('[')!=-1):
            filesnames.append(filepath.name) 
    return filesnames

def SolverExcel():
    excelfiles = []
    path = os.getcwd()
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name.find('.xlsx')!=-1 and filepath.name.find('Solver')!=-1):
            excelfiles.append(filepath.name) 
    return excelfiles



ExcelTemplate()
fichiers = ExistsXml()
for i in range(len(fichiers)):
    percentages(fichiers[i])
    



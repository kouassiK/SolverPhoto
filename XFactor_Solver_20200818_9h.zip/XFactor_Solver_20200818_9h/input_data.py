import os
import re
import glob
import pathlib
import pandas as pd
import openpyxl 
import xlsxwriter
import collections
import datetime
import dateutil.parser
import xml.etree.ElementTree as ET
import math
 
def ExistsXml():
    """
    Return True if an Excel file of the selected zip already exists
    Return False otherwise
    """
    path = os.getcwd()
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name.find('.xml')!=-1 and filepath.name.find('Solver')!=-1):
            print(filepath.name)
            return filepath.name



def parse_solution(nameXml):
    tree = ET.parse(nameXml)
    root = tree.getroot()
    keys = list(root[4][0].attrib.keys())
    
    global name_lots_solution #les numéros de lots dans solution.xml
    global occurrences
    name_lots_solution = []
    d = [] 
    tools = []
    for i in range(len(root[4])):
        tools.append(root[4][i].get('ToolID'))
        name_lots_solution.append(root[4][i].get('LotID'))
        d.append([root[4][i].get('ToolID'), root[4][i].get('LotID'),root[4][i].get('RouteStepID'), root[4][i].get('MaskID'), root[4][i].get('IsFrozen')])

    occurrences = collections.Counter(tools)
    #print(occurrences)
    unique_machines = list(set(tools))
    data = dict([(key,[]) for key in unique_machines])
    for i in range(len(d)):
        rank = 1
        if(d[i][0] in unique_machines):   
            t = []
            t.append(d[i][1]) #lotid
            t.append(d[i][2][:-5])#lattice 
            t.append(d[i][3])#mask
            t.append(d[i][4])#frozen
            data[d[i][0]].append(t)

    nums = [] 
    for k in data.keys():
        nums.append(int(k[3:]))
   
    nums.sort(reverse = False)
    #print(nums)
    chaines = []
    for j in nums:
        chaines.append(str(j))

    noms = []
    for j in chaines:
        if(len(j) < 2) :
            noms.append('CUV0' + j)
        else:
            noms.append('CUV' + j)

    #print(noms)
    final = dict([(key,[]) for key in noms])
    #print(final)
    

    for k in data.keys():
        for i in range(len(data.get(k))):
            data.get(k)[i].extend([i+1])
        
        
    for k in final.keys():
        final[k] = data[k]

    '''for k,v in final.items():
        print(k,v)'''
    #print(final.get('CUV01')[0])
    return final

def parse_lots(name, xml):
    '''
    Retourne #wafers, priority, startoperation des lots qui sont dans la solution et dans lots.txt
    '''
    solution = parse_solution(xml)
    path = os.getcwd()
    lines = []
    codes = []
    c = 0
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == name ):
            f = open(filepath,'r')
            c = len(open(filepath).readlines( ))
    for i in range(c):
        line = f.readline()
        t = line.split(';')
        lines.append(t)

    
    codes = []
    data_lots = dict([(key, 0) for key in codes])
    final = {}
    for i in range(1,len(lines)):
        codes.append(lines[i][0])
        data_lots[lines[i][0]] = [lines[i][3], lines[i][5], lines[i][6]] #wafers, priority, startoperation
     
    f.close()

    #les lots de la solution qui sont dans Lots.txt
    for k in data_lots.keys():
        if(k in name_lots_solution): 
            final[k] = data_lots.get(k)

    '''for k, v in final.items():
        print(k, v)'''

    return final

def parse_peb_processability(name, xml):
    '''
    Retourne #peb des lots de la solution
    '''
    solution = parse_solution(xml)
    path = os.getcwd()
    lines = []
    c = 0
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == name ):
            f = open(filepath,'r')
            c = len(open(filepath).readlines( ))
    for i in range(c):
        line = f.readline()
        t = line.split(';')
        lines.append(t)

    #print(lines)
    processability = []
    for i in range(1,len(lines)):
        toolID = lines[i][2]
        lotID = lines[i][0]
        latice = lines[i][1][:-5]
        PEB = lines[i][7].strip('\n')
        if(PEB == '' or len(PEB) > 3):
            processability.append([toolID, lotID, latice, 0])

        else:
            processability.append([toolID, lotID, latice,int(PEB)])

    for k in solution.keys():
        for j in range(len(solution.get(k))):
            for i in range(len(processability)):
                if (processability[i][0] == k and processability[i][1] == solution.get(k)[j][0]):
                    solution.get(k)[j].extend([processability[i][3]])
    
    for k,v in solution.items():
        print(k,v)
    return solution


def Excel(name, solution_name, lots_name, processability_name):
    solution = parse_solution(solution_name)
    lots = parse_lots(lots_name, solution_name)
    processability = parse_peb_processability(processability_name, solution_name)
    workbook = xlsxwriter.Workbook(name)
    worksheet = workbook.add_worksheet()
    worksheet.write('A1', 'ToolID') 
    worksheet.write('B1', 'Rank') 
    worksheet.write('C1', 'LotID')
    worksheet.write('D1', 'Priority')
    worksheet.write('E1', 'Wafers')
    worksheet.write('F1', 'LatticeCode')
    worksheet.write('G1', 'MasksID') 
    worksheet.write('H1', 'PEB')
    worksheet.write('I1', 'StartOperation')
    worksheet.write('J1', 'Frozen') 
    row = 1
    
    #print(occurrences)
    for k in solution.keys():
        for j in range(occurrences[k]):
            worksheet.write(row , 0, k) #ToolId
            #print(solution.get(k)[0][1])
            worksheet.write(row , 2, solution.get(k)[j][0]) #LotID
            worksheet.write(row , 5, solution.get(k)[j][1]) #Lattice
            worksheet.write(row , 6,solution.get(k)[j][2]) #MasksID
            worksheet.write(row , 9,solution.get(k)[j][3]) #frozen
            worksheet.write(row , 1,solution.get(k)[j][4])#rank
            row = row + 1
    workbook.close() 

    workbook1 = openpyxl.load_workbook(name) 
    worksheet = workbook1.worksheets[0]
    recap = pd.read_excel(name, sheet_name = 'Sheet1')
    colonnes = list(recap.columns.values)

    ws = workbook1.active
    #print(processability.get('CUV01')[0])

    for row in ws.iter_rows("A"):
        for any_cell in row: #any_cell.value = toolids
            if any_cell.value in processability.keys():
                #print(processability.get(any_cell.value)[0]
                for j in range(len(processability.get(any_cell.value))):
                    if (worksheet.cell(any_cell.row , 3).value ==  processability.get(any_cell.value)[j][0]): #lotID
                        worksheet.cell(any_cell.row , 8).value = processability.get(any_cell.value)[j][5]#peb


    for row in ws.iter_rows("C"):
        for any_cell in row:
            if any_cell.value in lots.keys():
                    worksheet.cell(any_cell.row , 5).value = lots.get(any_cell.value)[0] #wafers
                    worksheet.cell(any_cell.row , 4).value = lots.get(any_cell.value)[1] #priority
                    worksheet.cell(any_cell.row , 9).value = lots.get(any_cell.value)[2] #startoperation

    workbook1.save(name) 

    return workbook


#solution = parse_solution('Solver_20160624_8h2h_1_5_1000_up_-10.xml')
#parse_peb_processability('Processability.txt', 'Solver_20160624_8h2h_1_5_1000_up_-100.xml')
#Excel('Results_alpha_tsi = -10.xlsx', 'Solver_20160624_8h2h_1_5_1000_up_-10.xml', 'Lots.txt', 'Processability.txt')
Excel('Solver_20200703_14h2h_up_-10.xml' + '_Results_alpha_tsi = -10.xlsx', 'Solver_20200703_14h2h_up_-10.xml', 'Lots.txt', 'Processability.txt')


'''print(name_lots_solution)'''
#parse_lots('Lots.txt', 'Solver_20160627_9h4h_1_5_1000_up_-10.xml')
#parse_peb_processability('Processability.txt', 'Solver_20200721_15h2h_up_-1.xml')
import os
import glob
import pathlib
import openpyxl 
import xlsxwriter
import collections
import datetime
import dateutil.parser
import statistics
from collections import OrderedDict
import xml.etree.ElementTree as ET
import math
from orderedset import OrderedSet
from collections import Counter

def Excel():
    workbook = xlsxwriter.Workbook('PET.xlsx')
    workbook.close()

def proposal_solveur(nameXml):
    tree = ET.parse(nameXml)
    root = tree.getroot()
    infos = []
    tools = []
    for i in range(len(root[4])):
        tools.append(root[4][i].get('ToolID'))
        infos.append([root[4][i].get('ToolID'), root[4][i].get('LotID'), int(root[4][i].get('WaferCount'))]  ) #ids des lots de la solution solveur
    #print(infos)
 
    t = set(tools)

    nums = [] 
    for k in t:
        nums.append(int(k[3:]))
   
    nums.sort(reverse = False)
    #print(nums)
    chaines = []
    for j in nums:
        chaines.append(str(j))

    noms = []
    for j in chaines:
        if(len(j) < 2) :
            noms.append('CUV0' + j)
        else:
            noms.append('CUV' + j)

    #print(noms)
    d = dict([(key, []) for key in noms])
    res = dict([(key, []) for key in noms])
    for i in range(len(infos)):
            d[infos[i][0]].append(infos[i])

    for k in d.keys():
        prop = 0
        for i in range(len(d.get(k))):
            prop = prop + d.get(k)[i][2]          
        res[k] = prop

    '''for k,v in res.items():
        print(k,v)'''

    return res

def liste_machines(nameXml , index):
    name = "Processability.txt"
    path = os.getcwd()
    lines = []
    machines = [] #Processability.txt
    lots = [] #Lots.txt
    z = [] #pour récupérer lots et occurences
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == name ):
            f = open(filepath,'r')
            c = len(open(filepath).readlines( ))
    for i in range(c):
        line = f.readline()
        t = line.split(';')
        lines.append(t)

    for i in range(1,len(lines)):
        z.append(lines[i][0])
        machines.append(lines[i][2])

    machines = set(machines)
    z = Counter(z) #nombre de tools sur lesquels le lot est qualifié
    #print(machines)
    nums = [] 
    for k in machines:
        nums.append(int(k[3:]))
   
    nums.sort(reverse = False)
    #print(nums)
    chaines = []
    for j in nums:
        chaines.append(str(j))

    noms = []
    for j in chaines:
        if(len(j) < 2) :
            noms.append('CUV0' + j)
        else:
            noms.append('CUV' + j)

    #print(noms)

    lignes = []
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == "Lots.txt" ):
            g = open(filepath,'r')
            d = len(open(filepath).readlines())
    for i in range(d):
        line = g.readline()
        t = line.split(';')
        lignes.append(t)
    for i in range(1,len(lignes)):
        lots.append(lines[i][0])

    #print(lots)
    data = []
    for i in range(1,len(lignes)):
        data.append([lignes[i][0], int(lignes[i][3]), z[lignes[i][0]] ])

    #print(data)

    res = dict([(key, []) for key in noms])
    final = dict([(key, []) for key in noms])
    total_wafers =dict([(key, []) for key in noms])

    for i in range(len(lines)):
        if(lines[i][2] in res.keys()):
            res[lines[i][2]].append(lines[i][0])

    for i in range(len(data)):
        for k in res.keys():
            if(data[i][0] in res.get(k)):
                final[k].append(data[i])

    for k in final.keys():
        s = 0
        pot_partage = 0
        for i in range(len(final.get(k))):
            s = s + final.get(k)[i][1]
            pot_partage = pot_partage + final.get(k)[i][1] / final.get(k)[i][2]
        total_wafers[k] = [s, pot_partage ]

    '''for k,v in total_wafers.items():
        print(k,v)'''

    
    workbook = openpyxl.load_workbook('PET.xlsx') 
    worksheet = workbook.create_sheet(index)

    worksheet.cell(1, 1).value =  nameXml
    #worksheet.write(2, 1, nameXml)

    proposal = proposal_solveur(nameXml)
    ligne = 3
    for k in total_wafers.keys():
        worksheet.cell(ligne, 1).value  =  k
        worksheet.cell(ligne, 7).value =  total_wafers.get(k)[0] #potentiel
        worksheet.cell(ligne, 8).value =  total_wafers.get(k)[1] #potentiel partagé
        worksheet.cell(ligne, 9).value =  proposal.get(k)    #proposal
        ligne = ligne + 1
    workbook.save('PET.xlsx')

    return final

def ExistsXml():
    filesnames = []
    path = os.getcwd()
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name.find('.xml')!=-1 and filepath.name.find('[')!= -1 and filepath.name.find('(8_2_1')!=-1) :
            filesnames.append(filepath.name) 
    return filesnames

Excel()
fichiers = ExistsXml()
for i in range(len(fichiers)):
    liste_machines( fichiers[i], str(i))


   
#liste_machines()


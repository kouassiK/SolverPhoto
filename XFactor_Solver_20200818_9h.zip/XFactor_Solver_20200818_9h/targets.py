import os
import re
import glob
import pathlib
import pandas as pd
import openpyxl 
import xlsxwriter
import collections
import datetime
import dateutil.parser
import xml.etree.ElementTree as ET
import matplotlib.pyplot as plt
import pylab as plb
import numpy as np

def lattice_codes(nameXml):
    lattice_codes = []
    tree = ET.parse(nameXml)
    root = tree.getroot()
    keys = list(root[5][0].attrib.keys())  
    line = []
    
    for i in range(len(root[5])):  
        lattice_codes.append(root[5][i].get('ProductionTargetID'))
    #print(lattice_codes)
    return lattice_codes


def scheduled(nameXml):
    scheduled = []
    tree = ET.parse(nameXml)
    root = tree.getroot()
    keys = list(root[5][0].attrib.keys())  
    line = []
    lattices_codes = lattice_codes(nameXml)
    for i in range(len(root[5])):  
        line.append([root[5][i].get('ProductionTargetID'),root[5][i].get('TargetVolume'),root[5][i].get('InitialVolume'), root[5][i].get('FrozenVolume'),root[5][i].get('ScheduledVolume')])
    for i in range(len(line)):
        if(line[i][0] in lattices_codes):
            scheduled_volume = float(line[i][4])
            target_volume = float(line[i][1])
            scheduled.append((scheduled_volume / target_volume)*100)
    #print(len(scheduled))
    return scheduled

def initialVolume_list(nameXml):
    lattices_codes = lattice_codes(nameXml)
    initialVolume_list = []
    tree = ET.parse(nameXml)
    root = tree.getroot()
    keys = list(root[5][0].attrib.keys())  
    line = []
    for i in range(len(root[5])):      
        line.append([root[5][i].get('ProductionTargetID'),root[5][i].get('TargetVolume'),root[5][i].get('InitialVolume'), root[5][i].get('FrozenVolume'),root[5][i].get('ScheduledVolume')])

    for i in range(len(line)):
        if(line[i][0] in lattices_codes):
            initial_volume = float(line[i][2])
            target_volume = float(line[i][1])
            #Pour le graphe
            initialVolume_list.append((initial_volume / target_volume)*100)
    return initialVolume_list


def parse_solution(nameXml):
    lattices_codes = lattice_codes(nameXml)
    tree = ET.parse(nameXml)
    root = tree.getroot()
    keys = list(root[5][0].attrib.keys())  
    line = []
    
    for i in range(len(root[5])):      
        line.append([root[5][i].get('ProductionTargetID'),root[5][i].get('TargetVolume'),root[5][i].get('InitialVolume'), root[5][i].get('FrozenVolume'),root[5][i].get('ScheduledVolume')])

    data = dict([(key, 0) for key in lattices_codes])
    result = dict([(key, 0) for key in lattices_codes]) 

    for i in range(len(line)):
        if(line[i][0] in lattices_codes):
            initial_volume = float(line[i][2])
            scheduled_volume = float(line[i][4])
            target_volume = float(line[i][1])
            tableau = []
            tableau.append(initial_volume) #volume initial
            tableau.append(scheduled_volume)# volume proposé solveur
            tableau.append(target_volume) #volume target

            tableau.append((initial_volume/target_volume)*100)
            tableau.append(((scheduled_volume + initial_volume)/target_volume)*100)
            data[line[i][0]] = tableau
    for k,v in data.items():
        print(k,v)
    
    return data

'''print(len(lattice_codes("[0_0_1](8_2_1).xml")))
print(len(scheduled("[0_0_1](8_2_1).xml")))
print(len(initialVolume_list("[0_0_1](8_2_1).xml")))'''
#parse_solution("[0_0_1](8_2_1).xml")



def targets_fab():
    fichier = pd.read_excel('runSessionReport.xlsx')
    df = pd.DataFrame(fichier)
    l_codes = list(fichier.iloc[:, 4]) #tous les lattices fab
    wafers = list(fichier.iloc[:,5]) #tous les lots faits par latices en fab
    data = []
    for i in range(len(l_codes)):
        data.append([l_codes[i], wafers[i]])
        
    #print(data)
    codes = set(l_codes)
    dictionnaire = dict([(key, []) for key in codes])
    final = dict([(key, []) for key in codes])
    for k in dictionnaire.keys():
        for i in range(len(data)):
            if(k == data[i][0]) :
                dictionnaire[k].append(int(data[i][1]))

    for k in dictionnaire.keys():
        final[k] = sum(dictionnaire[k])

    '''for k, v in final.items():
        print(k, v)'''
    #print(len(final.keys()))

    return final
    
def ExistsExcel(ExcelFile):
    """
    Return True if an Excel file  already exists
    Return False otherwise
    """
    exists = False
    path = os.getcwd()
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == ExcelFile):
            exists = True
            return exists
        else:
            exists = False
    return exists

def Excel_first(name, data):
    workbook = xlsxwriter.Workbook('Equilibrage_'+ (name.strip('.xml')) +'.xlsx')
    worksheet = workbook.add_worksheet()
    #Write indicators in all worksheets
    worksheet.write('A1', 'ProductionTargetID ')
    worksheet.write('B1', 'Volume Initial ') 
    worksheet.write('C1', 'Volume Proposé')
    worksheet.write('D1', 'Volume Target')
    worksheet.write('E1', 'Initial / Target %')
    worksheet.write('F1', '(Scheduled + Initial) / Target %')
    j = 1
    lattices_codes = lattice_codes(name)
    initialVolume = initialVolume_list(name)
    s = scheduled(name)
    for i in range(len(data)):
        worksheet.write(j, 0, lattices_codes[i]) #prodID
        worksheet.write(j, 1, data.get(lattices_codes[i])[0]) #initial
        worksheet.write(j, 2, data.get(lattices_codes[i])[1])  #scheduled
        worksheet.write(j, 3, data.get(lattices_codes[i])[2]) #target
                                #Pourcentage
        worksheet.write(j, 4, data.get(lattices_codes[i])[3]) #initial/target
        worksheet.write(j, 5, data.get(lattices_codes[i])[4]) #(scheduled + initial) /target
        j = j + 1
    #Pour le stacked graphe 
    worksheet1 = workbook.add_worksheet('graphe')
    #Write indicators in all worksheets
    worksheet1.write('A1', 'ProductionTargetID')
    worksheet1.write('B1', 'Initial / Target %')
    worksheet1.write('C1', 'Scheduled  / Target %')
    k = 1
    for i in range(len(initialVolume)):
        worksheet1.write(k, 0, lattices_codes[i] ) #lattices
        worksheet1.write(k, 1, initialVolume[i]) #initial/target
        worksheet1.write(k, 2, s[i]) #scheduled  /target
        k = k + 1
    
    workbook.close() 
    return workbook
   
def Excel_not_first(nameXml, data):
    ExcelFileName = 'Equilibrage_'+ nameXml.strip('.xml')+'.xlsx'
    workbook = openpyxl.load_workbook(ExcelFileName) 
    worksheet = workbook.create_sheet()
    worksheet.cell(1,1).value =  'ProductionTargetID '
    worksheet.cell(1,2).value =  'Volume Initial '
    worksheet.cell(1,3).value =  'Volume Frozen '
    worksheet.cell(1,4).value =  'Volume Proposé'
    worksheet.cell(1,5).value =  'Volume Target'
    #Pourcentages
    worksheet.cell(1,6).value =  'Initial / Target %'
    worksheet.cell(1,7).value =  '(Scheduled + Initial) / Target %'
    j = 2
    
    for i in range(len(data)):
        worksheet.cell(j, 1).value = lattice_codes[i] #prodID
        worksheet.cell(j, 2).value = data.get(lattice_codes[i])[0] #initial
        worksheet.cell(j, 3).value = data.get(lattice_codes[i])[1] #scheduled
        worksheet.cell(j, 4).value = data.get(lattice_codes[i])[2] #target
        
        worksheet.cell(j, 5).value = data.get(lattice_codes[i-1])[3] #initial/target
        worksheet.cell(j, 6).value = data.get(lattice_codes[i-1])[4] #(scheduled + initial)/target'
        j = j + 1
       
    #Pour le graphe
    worksheet1 = workbook.create_sheet('graphe')
    #Write indicators in all worksheets
    worksheet1.cell(1,1).value =  'ProductionTargetID '
    worksheet1.cell(1,2).value = 'Initial / Target %'
    worksheet1.cell(1,3).value = 'Scheduled / Target %'
    k = 1
    for i in range(len(initialVolume_list)):
        worksheet1.cell(k, 1).value =  lattice_codes[i] #prodID
        worksheet1.cell(k, 2).value =  initialVolume_list[i] #initial/target
        worksheet1.cell(k, 3).value =  scheduled(nameXml)[i] #scheduled /target
        k = k + 1
    
    workbook.save(ExcelFileName)



def write_targets(name,data):
    ExcelFileName = 'Equilibrage_'+ name.strip('.xml') +'.xlsx'
    Excel_first(name,data)
    '''if(ExistsExcel(ExcelFileName)== True):
        Excel_not_first(name,data)
    if(ExistsExcel(ExcelFileName)== False):
        Excel_first(name,data)'''

def ExistsXml():
    path = os.getcwd()
    filesnames = []
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name.find('.xml')!=-1 and filepath.name.find('[')!=-1):
            filesnames.append(filepath.name) 
    return filesnames
             
'''fichiers = ExistsXml()
for i in range(len(fichiers)):
    write_targets(fichiers[i], parse_solution(fichiers[i]))'''





#write_targets('[0.1_1_1000000](8_2_1).xml', parse_solution('[0.1_1_1000000](8_2_1).xml'))
write_targets('[100000_1_1000000](8_2_1).xml', parse_solution('[100000_1_1000000](8_2_1).xml'))



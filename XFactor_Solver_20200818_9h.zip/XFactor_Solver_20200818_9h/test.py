import xml.etree.ElementTree as ET
from xml.etree import ElementTree
import openpyxl
import xlsxwriter
import pathlib
import shutil
import xlrd
import copy
import os

def FindSolutionPath():
    """
    Find the name path of file
    """
    path = os.getcwd()
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == "Solution.xml"):
            found = filepath
    return found

def FindSchedulizerRequestPath():
    """
    Find the name path of file
    """
    path = os.getcwd()
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == "SchedulizerRequest.request.xml"):
            found = filepath
    return found

def GetNumberMasksTransfers():
    """
    Get the number of masks transfer

    """
    with open('Solution.xml', 'rt') as f:
        tree = ElementTree.parse(f)
    number_masks_transfers = 0
    for node in tree.iter():
        if(node.tag == "OutputMaskTransfer"):
            number_masks_transfers = number_masks_transfers + 1 
            
    print(number_masks_transfers)
    return number_masks_transfers


def GetNumberTemperatureChanges():
    """
    Get the number of changing temperatures 

    """
    with open('Solution.xml', 'rt') as f:
        tree = ElementTree.parse(f)
    number_temperature_change = 0
    for node in tree.iter():
        if(node.tag == "OutputChangeover"):
            number_temperature_change = number_temperature_change  + 1 
            
    print(number_temperature_change)
    return number_temperature_change
        
def SaveValues(filepath):
    """
    Get the values of the indicators in Solution.xml
    
    """
    tree = ET.parse(filepath.name)
    #print(filepath.name)
    root = tree.getroot()
    #Recuperate results
    result = []
    xFactor = float(root[1][2].text)
    numberOfMoves = float(root[1][0].text)
    targetSatisfactionIndicator = float(root[1][1].text)
    result = [xFactor, numberOfMoves, targetSatisfactionIndicator,GetNumberMasksTransfers(), GetNumberTemperatureChanges()]
    
    #Conversion des paramètres
    print(result)
    return result

#SaveValues(FindSolutionPath())

def MoveSolution():
    """
    Return True if an Excel file of the selected zip already exists
    Return False otherwise
    """
    exists = False
    path = os.getcwd()
    print(path)
    for filepath in pathlib.Path(path).glob('**/*'): 
        #print(filepath.name)
        if(filepath.name == "Solution.xml"):
            print(filepath, path)
            real_dst = os.path.join(path, os.path.basename(filepath))
            shutil.move(filepath,real_dst)

def MoveSchedulizerRequest():
    """
    Return True if an Excel file of the selected zip already exists
    Return False otherwise
    """
    exists = False
    path = os.getcwd()
    print(path)
    for filepath in pathlib.Path(path).glob('**/*'): 
        #print(filepath.name)
        if(filepath.name == "SchedulizerRequest.request.xml"):
            print(filepath, path)
            real_dst = os.path.join(path, os.path.basename(filepath))
            shutil.move(filepath,real_dst)


def RenameSolution(extract, moves_windows)  :
    os.rename("Solution.xml","Solution_"+"extract_"+ "moves_windows"+".xml")

def MoveModelData():
    """
    Move the ModelData folder to the input folder
    """
    path = os.getcwd()
    model_data = os.path.join(path,r'ModelData')
    for filepath in pathlib.Path(path).glob('*/'): 
        if(filepath.name == "input" ):
            shutil.move(model_data ,filepath)

def MoveBackModelData():
    path = os.getcwd()
    print(path)
    for filepath in pathlib.Path(path).glob('*/*'): 
        #print(filepath.name)
        if(filepath.name == "ModelData"):
            print(filepath, path)
            real_dst = os.path.join(path, os.path.basename(filepath))
            shutil.move(filepath,real_dst)

MoveModelData()         
MoveBackModelData()


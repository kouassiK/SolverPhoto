import os
import glob
import pathlib


def only_High():
    name = "Lots.txt"
    path = os.getcwd()
    lines = []
    lots = []

    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == name ):
            f = open(filepath,'r')
            c = len(open(filepath).readlines( ))
           
    for i in range(c):
        line = f.readline()
        t = line.split(';')
        lines.append(t)
   
    for i in range(len(lines)):
        for j in range(len(lines[i])-1):
            lines[i][j] = lines[i][j]+';'

    new_file = open("Lots.txt", "w")
    for j in range(len(lines[0])):
        new_file.write(lines[0][j])

    for i in range(1,len(lines)):
        if(lines[i][5] != 'High_PIT;'):
            lines[i][5] = 'High_PIT;'
            for j in range(len(lines[i])):
                new_file.write(lines[i][j])
        else:
            for j in range(len(lines[i])):
                new_file.write(lines[i][j])

                
    new_file.close()

def only_Standard():
    name = "Lots.txt"
    path = os.getcwd()
    lines = []
    lots = []

    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == name ):
            f = open(filepath,'r')
            c = len(open(filepath).readlines( ))
           
    for i in range(c):
        line = f.readline()
        t = line.split(';')
        lines.append(t)
   
    for i in range(len(lines)):
        for j in range(len(lines[i])-1):
            lines[i][j] = lines[i][j]+';'

    new_file = open("Lots.txt", "w")
    for j in range(len(lines[0])):
        new_file.write(lines[0][j])

    for i in range(1,len(lines)):
        if(lines[i][5] != 'Standard_PIT;'):
            lines[i][5] = 'Standard_PIT;'
            for j in range(len(lines[i])):
                new_file.write(lines[i][j])
        else:
            for j in range(len(lines[i])):
                new_file.write(lines[i][j])

                
    new_file.close()

def only_Customer():
    name = "Lots.txt"
    path = os.getcwd()
    lines = []
    lots = []

    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == name ):
            f = open(filepath,'r')
            c = len(open(filepath).readlines( ))
           
    for i in range(c):
        line = f.readline()
        t = line.split(';')
        lines.append(t)
   
    for i in range(len(lines)):
        for j in range(len(lines[i])-1):
            lines[i][j] = lines[i][j]+';'

    new_file = open("Lots.txt", "w")
    for j in range(len(lines[0])):
        new_file.write(lines[0][j])

    for i in range(1,len(lines)):
        if(lines[i][5] != 'Customer_PIT;'):
            lines[i][5] = 'Customer_PIT;'
            for j in range(len(lines[i])):
                new_file.write(lines[i][j])
        else:
            for j in range(len(lines[i])):
                new_file.write(lines[i][j])

                
    new_file.close()


#only_High()

#only_Standard()

only_Customer()


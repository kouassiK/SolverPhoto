import os
import shutil
import pathlib
import xml.etree.ElementTree as ET

def parseSolution(filename):
    tree = ET.parse(filename)
    root = tree.getroot()
    keys = list(root[5][0].attrib.keys())
    InitialVolume = []
    ScheduledVolume = []
    for i in range(len(root[5])):
        InitialVolume.append(float(root[5][i].get('InitialVolume')))
        ScheduledVolume.append(float(root[5][i].get('ScheduledVolume')))
    sommes = [sum(InitialVolume), sum(ScheduledVolume)]
    return sommes

def ExistsText(TextFile):
    """
    Return True if a text file 
    Return False otherwise
    """
    exists = False
    path = os.getcwd()
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == TextFile):
            exists = True
            return exists
        else:
            exists = False
    print(exists)
    return exists

if(ExistsText("Solver_20160623_16h.txt")== True):
    fichier = open("Solver_20160623_16h" + ".txt", "a") 
    fichier.write("Your text goes here\t")
    fichier.write("\nand here")
    fichier.close()


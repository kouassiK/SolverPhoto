import os
import glob
import pathlib
import shutil
import pandas as pd
import openpyxl 
import xlsxwriter
import datetime
import dateutil.parser
import collections
import statistics
from collections import OrderedDict
import xml.etree.ElementTree as ET




def ChangeOverTime():
    path = os.getcwd()
    lines = []
    n = ""
    c = 0
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == "Processability.txt" ):
            n = filepath                
            f = open(filepath,'r')  
            c = len(open(filepath).readlines()) 
    for i in range(c):
        line = f.readline()
        t = line.split(';')
        lines.append(t)
    f.close()
    print(lines)  
    #print(n) 
    os.remove(n)
    g = open("Processability.txt", "a")
    g.write(lines[0][0] +";")
    g.write(lines[0][1]+";")
    g.write(lines[0][2]+";")
    g.write(lines[0][3]+";")
    g.write(lines[0][4]+";")
    g.write(lines[0][5]+";")
    g.write(lines[0][6]+";")
    g.write(lines[0][7])

    for i in range(1,len(lines)):
        if(lines[i][7]== '90\n'):
            g.write(lines[i][0]+";")
            g.write(lines[i][1]+";")
            g.write(lines[i][2]+";")
            g.write("A" + ";")
            g.write(lines[i][4]+";")
            g.write(lines[i][5]+";")
            g.write(lines[i][6]+";")
            g.write(lines[i][7])

        if(lines[i][7]== '95\n'):
            g.write(lines[i][0]+";")
            g.write(lines[i][1]+";")
            g.write(lines[i][2]+";")
            g.write("B"+ ";")
            g.write(lines[i][4]+";")
            g.write(lines[i][5]+";")
            g.write(lines[i][6]+";")
            g.write(lines[i][7])
        
        if(lines[i][7]== '100\n'):
            g.write(lines[i][0]+";")
            g.write(lines[i][1]+";")
            g.write(lines[i][2]+";")
            g.write("C"+";")
            g.write(lines[i][4]+";")
            g.write(lines[i][5]+";")
            g.write(lines[i][6]+";")
            g.write(lines[i][7])
            
        if(lines[i][7]== '105\n'):
            g.write(lines[i][0]+";")
            g.write(lines[i][1]+";")
            g.write(lines[i][2]+";")
            g.write("D" +";")
            g.write(lines[i][4]+";")
            g.write(lines[i][5]+";")
            g.write(lines[i][6]+";")
            g.write(lines[i][7])
        
        if(lines[i][7]== '110\n'):
            g.write(lines[i][0]+";")
            g.write(lines[i][1]+";")
            g.write(lines[i][2]+";")
            g.write("E" +";")
            g.write(lines[i][4]+";")
            g.write(lines[i][5]+";")
            g.write(lines[i][6]+";")
            g.write(lines[i][7])

        if(lines[i][7]== '115\n'):
            g.write(lines[i][0]+";")
            g.write(lines[i][1]+";")
            g.write(lines[i][2]+";")
            g.write("F" +";")
            g.write(lines[i][4]+";")
            g.write(lines[i][5]+";")
            g.write(lines[i][6]+";")
            g.write(lines[i][7])

        if(lines[i][7]== '120\n'):
            g.write(lines[i][0]+";")
            g.write(lines[i][1]+";")
            g.write(lines[i][2]+";")
            g.write("G" +";")
            g.write(lines[i][4]+";")
            g.write(lines[i][5]+";")
            g.write(lines[i][6]+";")
            g.write(lines[i][7])

        if(lines[i][7]== '125\n'):
            g.write(lines[i][0]+";")
            g.write(lines[i][1]+";")
            g.write(lines[i][2]+";")
            g.write("H" +";")
            g.write(lines[i][4]+";")
            g.write(lines[i][5]+";")
            g.write(lines[i][6]+";")
            g.write(lines[i][7])

        if(lines[i][7]== '130\n'):
            g.write(lines[i][0]+";")
            g.write(lines[i][1]+";")
            g.write(lines[i][2]+";")
            g.write("I" +";")
            g.write(lines[i][4]+";")
            g.write(lines[i][5]+";")
            g.write(lines[i][6]+";")
            g.write(lines[i][7])

        if(lines[i][7]== '140\n'):
            g.write(lines[i][0]+";")
            g.write(lines[i][1]+";")
            g.write(lines[i][2]+";")
            g.write("J" +";")
            g.write(lines[i][4]+";")
            g.write(lines[i][5]+";")
            g.write(lines[i][6]+";")
            g.write(lines[i][7])
    g.close()

   
    

        

        
ChangeOverTime()
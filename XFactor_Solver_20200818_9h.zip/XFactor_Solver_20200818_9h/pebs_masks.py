import os
import glob
import pathlib
import pandas as pd
import openpyxl 
import xlsxwriter
import datetime
import dateutil.parser
import collections
import statistics
from collections import OrderedDict
import xml.etree.ElementTree as ET

def ExcelTemplate():
    workbook = xlsxwriter.Workbook("ResultatsComparatifs.xlsx")
    worksheet = workbook.add_worksheet()
    worksheet.write('A1', 'Parameters') 
    worksheet.write('B1', 'Wafers')
    worksheet.write('C1', 'PEB') 
    worksheet.write('D1', 'Masks')
    workbook.close()

def evaluationSessionReport():
    fichier = pd.read_excel('runSessionReport.xlsx')
    df = pd.DataFrame(fichier)
    tools = list(fichier.iloc[:, 0]) #tous les tools faits en fab
    lots = list(fichier.iloc[:,1]) #tous les lots faits en fab
    lots_tools = []
    for i in range(len(tools)):
        lots_tools.append([tools[i], lots[i]])

    nums = [] 
    noms_tools = list(set(tools))
    for k in noms_tools:
        nums.append(int(k[3:]))
    nums.sort(reverse = False)
    #print(nums)
    chaines = []
    for j in nums:
        chaines.append(str(j))
    noms = []
    for j in chaines:
        if(len(j) < 2) :
            noms.append('CUV0' + j)
        else:
            noms.append('CUV' + j)

    result = dict([(key,[]) for key in noms])
    #print(lots_tools)
    for i in range(len(lots_tools)):
        if(lots_tools[i][0] in result.keys()):
            result[lots_tools[i][0]].append(lots_tools[i][1])
    #les tools et les lots correspondant sont dans new
    '''for k,v in result.items():
        print(k,v)'''

    workbook = xlsxwriter.Workbook('evaluationSessionReport.xlsx') 
    worksheet = workbook.add_worksheet()
    i = 0
    for k in result.keys():  
        for j in range(len(result[k])):
            worksheet.write(0,i,k)
            worksheet.write(j+1,i,result[k][j])
        i = i + 1
        
    workbook.close()
    occ = collections.Counter(tools) #le nombre de peb par équipement
    return occ
    #print(occ) 
    
def wafersSessionReport(nameXml):
    #####################################Somme totale des wafers dans la solution############################################
    
    fichier = pd.read_excel('runSessionReport.xlsx')
    df = pd.DataFrame(fichier)
    wafers_count = list(fichier.iloc[:,5]) #wafers_count
    total = list(map(int, wafers_count))
    with open("TotalWafersCount_" + nameXml.strip('.xml') +".txt" , "a") as f:
        f.write("Nombre total de wafers réalisé par la fab : " + str(sum(total)) +"\n")
        f.close()
    ##########################################################################################################################


def  allLotsWafersCount():
    name = "Lots.txt"
    path = os.getcwd()
    lines = []
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == name ):
            f = open(filepath,'r')
            c = len(open(filepath).readlines( ))
    for i in range(c):
        line = f.readline()
        t = line.split(';')
        lines.append(t)

    lots_wafers = []
    for i in range(1,len(lines)):
        lots_wafers.append([lines[i][0], lines[i][3]])
    
    return lots_wafers
     
def tool_masks_peb(nameXml):
    tree = ET.parse(nameXml)
    root = tree.getroot()
    tools = [] 
    tools_masks = []
    infos = []
    lots = []
    for i in range(len(root[4])):
        lots.append(root[4][i].get('LotID')) #ids des lots de la solution solveur
        infos.append([root[4][i].get('LotID'),root[4][i].get('ToolID')]) #ids des lots et tools de la solution solveur
        tools.append(root[4][i].get('ToolID')) #ids des tools de la solution solveur
        tools_masks.append([root[4][i].get('ToolID'), root[4][i].get('MaskID')]) #ids des tools et masques de la solution solveur
    
    #print(tools_masks)
    ##########################pour obtenir dans ordre_tools la liste des tools ordonnés #################
    nums = [] 
    for k in tools:
        nums.append(int(k[3:]))
    nums.sort(reverse = False)
    #print(nums)
    chaines = []
    for j in nums:
        chaines.append(str(j))
    noms = []
    for j in chaines:
        if(len(j) < 2) :
            noms.append('CUV0' + j)
        else:
            noms.append('CUV' + j)

    #ordonne les noms des tools
    ordre_tools = list(dict.fromkeys(noms))
    #présentation tools et les lots associés
    tools_lots = dict([(key,[]) for key in ordre_tools])
    for i in range(len(infos)):
        if(infos[i][1] in tools_lots.keys()):
            tools_lots[infos[i][1]].append(infos[i][0])

#############################remplir tools et lots correspondants##################
    #for k,v in tools_lots.items():
        #print(k, v)
    workbook_solveur = xlsxwriter.Workbook(nameXml.strip('.xml')+'.xlsx') 
    worksheet_solveur = workbook_solveur.add_worksheet()
    u = 0
    for k in tools_lots.keys():  
        for j in range(len(tools_lots[k])):
            worksheet_solveur.write(0,u,k)
            worksheet_solveur.write(j+1,u,tools_lots[k][j])
        u = u + 1
        
    workbook_solveur.close()

#################################################################################
    #tools et masks dans data
    data = dict([(key,[]) for key in ordre_tools])
    for i in range(len(tools_masks)):
        data[tools_masks[i][0]].append(tools_masks[i][1])

    #for k,v in data.items():
        #print(k, v)

    correct_transferts = dict([(key,[]) for key in data.keys()]) 
    for k in data.keys():
        transferts = 0
        for i in range(1, len(data[k])):
            if(data[k][i-1] != data[k][i]):
                    transferts = transferts + 1
            if(data[k][i-1] == data[k][i]):
                transferts = transferts
        correct_transferts[k]  = transferts

    '''for k, v in correct_transferts.items():
        print(k, v)'''

    ############################################################################ PEB ##################################################################""""

    #name = "Processability" + nameXml.split('h') +".txt"
    name = "Processability.txt"
    path = os.getcwd()
    lines = []
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == name ):
            f = open(filepath,'r')
            c = len(open(filepath).readlines( ))
    for i in range(c):
        line = f.readline()
        t = line.split(';')
        lines.append(t)

    processability = []
    machines = []
    list_tools_complete = []
    for i in range(1,len(lines)):
        lotID = lines[i][0]
        toolID = lines[i][2]
        PEB = lines[i][7].strip('\n')
        list_tools_complete.append(toolID)
        if([lotID , toolID] in infos):
            processability.append([toolID, PEB]) #les peb et tool dont le lot est dans la solution within horizon
            machines.append(toolID)


    #pour compter le nombre de lots prévus par machine au total données lues dans Processability.txt
    occurrences = collections.Counter(list_tools_complete)
    #print(occurrences)


    machines_list = collections.Counter(machines) #le nombre de peb par équipement
    #print(machines_list)
    new = dict([(key,[]) for key in machines_list.keys()])

    for i in range(len(processability)):
        if(processability[i][0] in new.keys()):
            new[processability[i][0]].append(processability[i][1])
    ###################################################################nombre correct de peb###################################
    correct_peb = dict([(key,[]) for key in data.keys()]) 
    for k in new.keys():
        chgts_peb = 0
        for i in range(len(new[k])-1):
            if(new[k][i] != new[k][i + 1]):
                chgts_peb = chgts_peb + 1
        correct_peb[k] = chgts_peb

    #for k,v in correct_peb.items():
        #print(k,v)
    #############################################################################################

    final_result = dict([(key,[]) for key in data.keys()])
    for k in data.keys():
        final_result[k] = [ correct_peb[k], correct_transferts[k] ]

    # final_result = tool[peb, transferts de masques] within horizon et processability.txt
    '''for k,v in final_result.items():
        print(k,v)'''

    
    ##################################################################################################
    workbook = xlsxwriter.Workbook('PEB_Masks_'+ nameXml.strip('.xml') +'.xlsx') 
    liste = workbook.sheetnames
    nom_feuille = nameXml.strip('.xml')
    if name not in liste: # Excel existe et la feuille n'existe pas 
        #on crée la feuille
        #worksheet = workbook.create_sheet(nom_feuille)
        worksheet = workbook.add_worksheet()
        worksheet.write(0,0,'Tool')
        worksheet.write(0,1,'PEB')
        worksheet.write(0,2,'Transferts masques')
        worksheet.write(0,3,'Lots qualifiés')
        worksheet.write(0,4,'Lots Solveur')
        j = 1
        total_chgts_peb = 0
        total_transferts_masks = 0
        for k in final_result.keys():
            worksheet.write(j,0, k) #Tool
            worksheet.write(j,1,final_result.get(k)[0]) #Nombre de PEB
            total_chgts_peb = total_chgts_peb + int(final_result.get(k)[0])
            worksheet.write(j,2,final_result.get(k)[1]) #Nombre de transferts de masques
            total_transferts_masks = total_transferts_masks + int(final_result.get(k)[1])
            worksheet.write(j,3,occurrences[k])#Nombre de lots qualifiés
            worksheet.write(j,4,machines_list[k]) #Nombre de lots ordonnancés Solveur
            j = j + 1
        workbook.close()

        ################################# wafers count total######################

        listeComp = allLotsWafersCount()
        wafers = 0
        for i in range(len(listeComp)):
            if(listeComp[i][0] in lots):
                print(listeComp[i][0])
                wafers = wafers + int(listeComp[i][1]) #proposition solveur
        with open("TotalWafersCount_"+nameXml.strip('.xml')+".txt", "a") as f:
            f.write("Nombre total de wafers proposé par le solveur : " + str(wafers))
            f.close()

        ##################################### remplissage ResultatsComparatifs.xlsx (pour le solveur avec les différents paramétrages)###############
        
        book = openpyxl.load_workbook('ResultatsComparatifs.xlsx')
        sheet = book.worksheets[0]
        row = sheet.max_row
        sheet.cell(row+1 , 1).value = nameXml.strip('.xml')
        sheet.cell(row+1 , 2).value = str(wafers)
        sheet.cell(row+1 , 3).value = total_chgts_peb
        sheet.cell(row+1 , 4).value = total_transferts_masks
        book.save('ResultatsComparatifs.xlsx')
        
def ExistsXml():
    filesnames = []
    path = os.getcwd()
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name.find('.xml')!=-1 and filepath.name.find('[')!=-1):
            filesnames.append(filepath.name) 
    return filesnames

#ExcelTemplate()
fichiers = ExistsXml()
for i in range(len(fichiers)):
    tool_masks_peb(fichiers[i])



 

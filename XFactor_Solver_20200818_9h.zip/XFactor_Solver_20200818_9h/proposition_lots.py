import os
import glob
import pathlib
import openpyxl 
import xlsxwriter
import collections
import datetime
import dateutil.parser
import statistics
from collections import OrderedDict
import xml.etree.ElementTree as ET
import math


def liste_lots_fab():
    name = "Lots.txt"
    path = os.getcwd()
    lines = []
    lots = []
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == name ):
            f = open(filepath,'r')
            c = len(open(filepath).readlines( ))
    for i in range(c):
        line = f.readline()
        t = line.split(';')
        lines.append(t)

    lots = [] #Dans Lots.txt
    
    for i in range(1,len(lines)):
        lots.append(lines[i][0])

    #print(len(lots))
    return lots
    

def liste_lots_solveur(nameXml):
    tree = ET.parse(nameXml)
    root = tree.getroot()
    infos = []
    for i in range(len(root[4])):
        infos.append(root[4][i].get('LotID'))
    #print(len(infos))
    return infos


def lots_fab():
    name = "Lots.txt"
    path = os.getcwd()
    lines = []
    masks = []
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == name ):
            f = open(filepath,'r')
            c = len(open(filepath).readlines( ))
    for i in range(c):
        line = f.readline()
        t = line.split(';')
        lines.append(t)

    lots = [] #Dans Lots.txt
    
    for i in range(1,len(lines)):
        masks.append(lines[i][21]) 
        date = dateutil.parser.isoparse(lines[i][6].strip('\n'))
        lots.append([lines[i][0], lines[i][21], date, str(lines[i][5]) ] ) #lotId, masque, operStart, priority

    masks_ids = set(masks)
    data_lots = dict([(key, []) for key in masks_ids])


    for i in range(len(lots)):
        if(lots[i][1] in data_lots.keys()): #si le masque est une clé
            data_lots[lots[i][1]].append(lots[i])

    '''for k,v in data_lots.items():
        print(k,v)'''

    return data_lots

def proposition_solveur(nameXml):
    tree = ET.parse(nameXml)
    root = tree.getroot()
    infos = []
    masks = []
    for i in range(len(root[4])):
        masks.append(root[4][i].get('MaskID'))
        date = dateutil.parser.isoparse(root[4][i].get('OperationStartDateTime'))
        infos.append([root[4][i].get('LotID'), root[4][i].get('MaskID'), date , root[4][i].get('PriorityClass') ]) #ids des lots de la solution solveur

     
    m = set(masks)
    d = dict([(key, []) for key in m])
    for i in range(len(infos)):
        if(infos[i][1] in d.keys()): #si le masque est une clé
            d[infos[i][1]].append(infos[i])

    '''for k,v in d.items():
        print(k,v)'''

    return d


def solveur_hours(nameXml):
    tree = ET.parse(nameXml)
    root = tree.getroot()
    infos = []
    masks = []
    for i in range(len(root[4])):
        masks.append(root[4][i].get('MaskID'))
        date = dateutil.parser.isoparse(root[4][i].get('OperationStartDateTime'))
        infos.append([root[4][i].get('LotID'), root[4][i].get('MaskID'), date , root[4][i].get('PriorityClass') ]) #ids des lots de la solution solveur

    m = set(masks)
    d = dict([(key, []) for key in m])
    for i in range(len(infos)):
        if(infos[i][1] in d.keys()): #si le masque est une clé
            d[infos[i][1]].append(infos[i])

    '''for k,v in d.items():
        print(k,v)'''

    return d


def compare_dates(dict_fab, dict_solveur):
    l = list(set(lots_fab).symmetric_difference(set(lots_solveur))) #lots dans fab mais pas dans la solution solveur
    m = [] 

    for k in dict_fab.keys():
        for i in range(len(dict_fab.get(k))):
            if((dict_fab.get(k)[i][0] in l) and (k  in dict_solveur.keys())): #dans la fab et pas réalisé
                m.append(k)

    result_comparaison = dict([(key, []) for key in m]) 
    for k in dict_fab.keys():
        for i in range(len(data_fab.get(k))):
                if((dict_fab.get(k)[i][0] in l) and (k  in dict_solveur.keys())): #dans la fab et pas réalisé
                    result_comparaison[k].append(dict_fab.get(k)[i])

    res = dict([(key, []) for key in dict_fab.keys()])
    
        

    return res


'''def compare_dates(dict_fab, dict_solveur):
    data_fab = [[k,v] for k,v in dict_fab.items()]
    data_solveur = [[k,v] for k,v in dict_solveur.items()]
    res = dict([(key, []) for key in dict_fab.keys()])


    for i in range(len(data_fab)):
        for j in range(len(data_fab[i])):
            print(data_fab[i][j][0])
            for k in range(len(data_solveur)):
                for u in range(len(data_solveur[k])):
                    #
                    if(data_fab[i][j][0] < data_solveur[k][u][0]):
                        res[data_fab[i][j]].append(data_solveur[k][u][2])'''


def Excel():
    workbook = xlsxwriter.Workbook('Resultats_Propositions' + '.xlsx') 

    workbook.close()

#Comparer les dates des lots proposés (par le solveur) par masque 
def comparaison(index,nameXml,lots_fab, lots_solveur, data_fab, data_solveur):
    workbook = openpyxl.load_workbook('Resultats_Propositions.xlsx') 
    worksheet = workbook.create_sheet(index)
    
    worksheet.cell(1,1).value = nameXml
    worksheet.cell(2,1).value =  "FAB"
    worksheet.cell(3,1).value =  "Masks"
    worksheet.cell(3,2).value =  "Lots"
    worksheet.cell(3,3).value =  "Operation"
    worksheet.cell(3,4).value =  "Priority"

    worksheet.cell(2,6).value =  "SOLVEUR"
    worksheet.cell(3,6).value =  "Lots"
    worksheet.cell(3,7).value =  "OperDate"
    worksheet.cell(3,8).value =  "Priority"

    l = list(set(lots_fab).symmetric_difference(set(lots_solveur))) #lots dans fab mais pas dans la solution solveur
    #print(l)   
    m = [] 

    for k in data_fab.keys():
        for i in range(len(data_fab.get(k))):
            if((data_fab.get(k)[i][0] in l) and (k  in data_solveur.keys())): #lots dans la fab et pas réalisé et dont les masques sont dans la solution solveur
                m.append(k)
     
    #print(m)
    result_comparaison = dict([(key, []) for key in m]) 
    dates_index = dict([(key, []) for key in m])
          
    #on stocke toutes les données des lots non proposés par le solveur
    for k in data_fab.keys():
        for i in range(len(data_fab.get(k))):
                if((data_fab.get(k)[i][0] in l) and (k  in data_solveur.keys())): #dans la fab et pas réalisé
                    result_comparaison[k].append(data_fab.get(k)[i])

    solver_hours = solveur_hours(nameXml) #dictionnaire clé id masque et éléments date de opérartionStart
    
 
    #print(len(result_comparaison.keys()), len(solver_hours.keys()))

    final =  dict([(key, []) for key in solver_hours.keys()]) 
    for k in result_comparaison.keys():
        for i in range(len(result_comparaison.get(k))):
            for j in range(len(solver_hours.get(k))):
                #print(solver_hours.get(k)[j])
                if(result_comparaison.get(k)[i][2] <  solver_hours.get(k)[j][2] ):
                    l = []
                    l.append(result_comparaison.get(k)[i][0])
                    l.append(result_comparaison.get(k)[i][2])
                    l.append(result_comparaison.get(k)[i][3])# ce qui vient avant
                    l.append(solver_hours.get(k)[j][0]) #ce que le solveur a pris à la place lot
                    l.append(solver_hours.get(k)[j][2]) #ce que le solveur a pris à la place date
                    l.append(solver_hours.get(k)[j][3]) #ce que le solveur a pris à la place priorité
                    final[k] = l
                    
       
    ligne = 4
    for k in final.keys():
        if len(final.get(k)) > 0 :
                #print(final.get(k))
                worksheet.cell(ligne, 1).value = k #masks
                #print(len(final.get(k)))              
                #print(result_comparaison.get(k)[i])
                worksheet.cell(ligne, 2).value =  final.get(k)[0] #lots
                worksheet.cell(ligne, 3).value = final.get(k)[1]#dates
                worksheet.cell(ligne, 4).value = final.get(k)[2] #priorités

                worksheet.cell(ligne, 6).value = final.get(k)[3] #lot du solveur qui vient après
                worksheet.cell(ligne, 7).value = final.get(k)[4] #date du lot du solveur qui vient après
                worksheet.cell(ligne, 8).value = final.get(k)[5] #prioritédu lot du solveur qui vient après
                ligne = ligne + 1

    workbook.save('Resultats_Propositions.xlsx')

    '''for k in final.keys():
        if len(final.get(k)) > 0 :
            print(final.get(k)[0])'''

    for k, v in solver_hours.items():
        print(k, v)

   
#comparaison('[0_1_0](1_1_1).xml', liste_lots_fab(), liste_lots_solveur('[0_1_0](1_1_1).xml'), lots_fab(), proposition_solveur('[0_1_0](1_1_1).xml'))


def ExistsXml():
    filesnames = []
    path = os.getcwd()
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name.find('.xml')!=-1 and filepath.name.find('[')!= -1 and filepath.name.find('(1_1_1')!=-1) :
            filesnames.append(filepath.name) 
    return filesnames

#Excel()
fichiers = ExistsXml()
#print(fichiers)
for i in range(len(fichiers)):
    comparaison(str(i), fichiers[i], liste_lots_fab(), liste_lots_solveur(fichiers[i]), lots_fab(), proposition_solveur(fichiers[i]))



             
        
        

       

    
    

    

#liste_lots_fab()
#liste_lots_solveur('[0_1_0](8_2_1).xml')

#proposition_solveur('[0_1_0](8_2_1).xml')
#comparaison('[1_1000_1](1_1_1).xml', liste_lots_fab(), liste_lots_solveur('[1_1000_1](1_1_1).xml'), lots_fab(), proposition_solveur('[1_1000_1](1_1_1).xml'))
#solveur_hours('[0_1_0](8_2_1).xml')

#compare_dates(lots_fab(), proposition_solveur('[0_1_0](8_2_1).xml'))
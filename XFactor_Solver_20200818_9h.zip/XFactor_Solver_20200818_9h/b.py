import os
import re
import glob
import pathlib
import pandas as pd
import openpyxl 
import xlsxwriter
import collections
import datetime
import dateutil.parser
import xml.etree.ElementTree as ET
import math


'''lotsID = []
    for i in range(len(processability)):
        lotsID.append(processability[i][0])

    s = set(lotsID)
    final = []
    occurrences = collections.Counter(lotsID)

    data_peb = dict([(key, 0) for key in s])
    for lot in s:
        #print(lot, lotsID.index(lot))
        debut = lotsID.index(lot) #première apparition de l'ID de lot
        nombre_fois = occurrences[lot] #nombre d'apparitions de l'ID du lot
        total = 0
        for i in range(nombre_fois):
            total = total + processability[debut+i][2]
       #print(lot, total)
        data_peb[lot] = total

    f.close()
    final = {}

    for k in data_peb.keys():
        if(k in name_lots_solution): 
            final[k] = data_peb.get(k)'''

    '''for k, v  in solution.items():
        print(k, v)'''


'''def parse_rank_TTL(name):
    path = os.getcwd()
    lines = []
    global lattice_codes
    global data_ttl
    lattice_codes = []
    c = 0
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == name ):
            f = open(filepath,'r')
            c = len(open(filepath).readlines( ))
    for i in range(c):
        line = f.readline()
        t = line.split(';')
        lines.append(t)

    data_ttl = dict([(key, []) for key in lattice_codes])
    for i in range(1, len(lines)):
        lattice_codes.append(lines[i][1][:-5])
        data_ttl[i-1] = [lines[i][0],  lines[i][1][:-5], lines[i][2], lines[i][5].strip('\n')]
    
    for k, v  in data_ttl.items():
        print(k, v)        
    f.close()
    return data_ttl




def parse_peb_processability(name):
    path = os.getcwd()
    lines = []
    c = 0
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == name ):
            f = open(filepath,'r')
            c = len(open(filepath).readlines( ))
    for i in range(c):
        line = f.readline()
        t = line.split(';')
        lines.append(t)

    #print(lines)
    processability = []
    for i in range(1,len(lines)):
        lotID = lines[i][0]
        latice = lines[i][1][:-5]
        PEB = lines[i][7].strip('\n')
        if(PEB == '' or len(PEB) > 3):
            processability.append([lotID, latice, 0])

        else:
            processability.append([lotID, latice,int(PEB)])

    lotsID = []
    for i in range(len(processability)):
        lotsID.append(processability[i][0])

    s = set(lotsID)
    final = []
    occurrences = collections.Counter(lotsID)

    data_peb = dict([(key, 0) for key in s])
    for lot in s:
        #print(lot, lotsID.index(lot))
        debut = lotsID.index(lot) #première apparition de l'ID de lot
        nombre_fois = occurrences[lot] #nombre d'apparitions de l'ID du lot
        total = 0
        for i in range(nombre_fois):
            total = total + processability[debut+i][2]

        #print(lot, total)
        data_peb[lot] = total

    for k, v  in data_peb.items():
        print(k, v)

    f.close()
    #print(len(s), len(data_peb))
    return data_peb

def Excel(name, solution):
    workbook = xlsxwriter.Workbook(name)
    worksheet = workbook.add_worksheet()
    worksheet.write('A1', 'LotID') 
    worksheet.write('B1', 'LatticeCode') 
    worksheet.write('C1', 'ToolID')
    worksheet.write('D1', 'MasksID')
    worksheet.write('E1', 'Wafers')
    worksheet.write('F1', 'Priority')
    worksheet.write('G1', 'Rank') 
    worksheet.write('H1', 'PEB')
    row = 1
    
    for k in solution.keys():
        worksheet.write(row , 0, k) #LotId
        worksheet.write(row , 1, solution[k][0]) #Lattice code
        worksheet.write(row , 2, solution[k][1]) #ToolID
        worksheet.write(row , 3, solution[k][2]) #MasksID
        row = row + 1
    workbook.close() 
    return workbook



def Excel(name, lots, ttl, solution):
    workbook = xlsxwriter.Workbook(name)
    worksheet = workbook.add_worksheet()
    worksheet.write('A1', 'LotID') 
    worksheet.write('B1', 'LatticeCode') 
    worksheet.write('C1', 'ToolID')
    worksheet.write('D1', 'MasksID')
    worksheet.write('E1', 'Wafers')
    worksheet.write('F1', 'Priority')
    worksheet.write('G1', 'Rank') 
    worksheet.write('H1', 'PEB')
    row = 1
    #On écrit les données de Lots.txt
    for i in range(len(lots)):
        worksheet.write(row , 0, lots[i][0]) #LotId
        worksheet.write(row , 1, lots[i][1]) #Lattice code
        worksheet.write(row , 3, lots[i][4]) #MasksID
        worksheet.write(row , 4, lots[i][2]) #Wafers
        worksheet.write(row , 5, lots[i][3]) #Priority
        row = row + 1
    workbook.close()

    workbook1 = openpyxl.load_workbook(name) 
    worksheet = workbook1.worksheets[0]
    recap = pd.read_excel(name, sheet_name = 'Sheet1')
    colonnes = list(recap.columns.values)
    masks = list(recap.iloc[:, 3]) #masques présents dans Results.txt
    index = list(recap.iloc[:, 0]) #lots id présents dans Results.txt
    n = len(lots)
    cles = list(ttl.values()) #valeurs de ttl.txt
    codes = []
    ranks = []
    for i in range(len(cles)):
        codes.append(cles[i][0]) #lots id de ttl
        ranks.append(cles[i][3]) #rangs des lots de TTL

    #print(ranks_lots_ttl)

    doublons = []#liste des lots à la fois dans ttl et lots
    ranks_lots_ttl = 
    for j in range(len(index)):
        if index[j] in codes: #les lots dans ttl.txt et lots.txt(déjà écrits dans Results.xlsx)
            doublons.append(index[j])#les lots en double
            #print(index[j], codes.index(index[j]), ranks[codes.index(index[j])])
            ranks_lots_ttl[index[j]] = ranks[codes.index(index[j])]
  
    row = row + 1
    for i in range(len(ttl)):       
        if(ttl[i][0] not in doublons): #on écrit les lots qui ne sont pas en double(seulzmznt dans la ttl)
            worksheet.cell(row , 1).value = ttl[i][0] #LotId
            worksheet.cell(row , 2).value = ttl[i][1] #Lattice code
            worksheet.cell(row , 3).value = ttl[i][2] #ToolID
            worksheet.cell(row , 7).value = ttl[i][3] #Rank
            row = row + 1

    print(ranks_lots_ttl)
    #les lots en double(qui sont dans lots.txt et ttl.txt et qui ont un rank)
    ws = workbook1.active
    for row in ws.iter_rows("A"):
        for any_cell in row:
            if any_cell.value in doublons:
                worksheet.cell(any_cell.row , 7).value = ranks_lots_ttl.get(any_cell.value) #Rank

    #print(masks)
    m = 0
    for i in range(len(masks)):
        if(type(masks[i]) == float and math.isnan(masks[i]) and index[i] in solution.keys()):
            #print(index[i], solution[index[i]][1])
            m = m + 1
            worksheet.cell(n + 2, 4).value =  solution[index[i]][1] #MasksID
            n = n + 1
    workbook1.save(name)
    
     
    return workbook

def Fill_Tool_Masks(name,solution):
    workbook = openpyxl.load_workbook(name) 
    worksheet = workbook.worksheets[0]
    recap = pd.read_excel(name, sheet_name = 'Sheet1')
    list_lotsID = list(recap.columns.values)
    ids = list(recap.iloc[:, 0])
    for i in range(len(ids)):
        #if ids[i] in solution.keys():
            worksheet.cell(ids.index(ids[i]) + 2, 3).value = solution.get(ids[i])[0]
            worksheet.cell(ids.index(ids[i]) + 2, 4).value = solution.get(ids[i])[1]
        

    workbook.save(name)

def Fill_PEB(name,peb, toolids): 

    workbook = openpyxl.load_workbook(name) 
    worksheet = workbook.worksheets[0]
    recap = pd.read_excel(name, sheet_name = 'Sheet1')
    list_lotsID = list(recap.columns.values)
    ids = list(recap.iloc[:, 0])
    for i in range(len(ids)):
        if ids[i] in peb.keys():
            n = i+2
            #print(i, ids[i])
            worksheet.cell(ids.index(ids[i]) + 2, 8).value = peb.get(ids[i])
    for i in range(len(ids)):
        if ids[i] in toolids.keys():
            worksheet.cell(ids.index(ids[i]) + 2, 3).value = toolids.get(ids[i])[0]

    workbook.save(name)
        
solution = parse_solution('Solver_20160627_9h4h_1_5_1000_up_-10.xml')

lots = parse_lots('Lots.txt')
ttl = parse_rank_TTL('TTL.txt')
Excel('Results.xlsx', lots,ttl, solution)
pe  = parse_peb_processability('Processability.txt')
Fill_PEB('Results.xlsx', pe, solution)'''

#ExistsXml()
import os
import re
import glob
import pathlib
import pandas as pd
import openpyxl 
import xlsxwriter
import collections
import datetime
import dateutil.parser
import xml.etree.ElementTree as ET

tool_statuses = []

def FindSolutionPath():
    '''
    Fournit le chemin du fichier Excel dans lequel écrire les résultats
    '''
    path = os.getcwd()
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == "result_presentation.xlsx" ): 
            f = filepath
    return f

def GetOrigin_Lots_Ord(name):
    '''
    Fournit horizon de référence pour calcul des lots ordonnancés
     =  origine(prise dans ToolStatuses.txt) + 4h
    '''
    global horizonrefs
    origin = ''
    path = os.getcwd()
    fichier = name.strip('.xml')[:-2] +'.txt'
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == fichier ):
            f = open(filepath,'r')
            lines = f.readlines()
            line = lines[1] #Seconde ligne
            t = line.split(';') #séparation de la ligne selon les ;
            origin = t[4]# récupération de l'origine
            f.close()
    
    #print(fichier)
    date_str = origin.strip('\n')
    #date_time_obj = datetime.datetime.strptime(date_str, '%Y-%m-%d %H:%M:%S')#formattage de la date
    t = date_time_obj.time()
    h = int(t.hour)
    m = int(t.minute)
    s = int(t.second)
    hours = datetime.time(h,0,0)
    a = datetime.timedelta(0, (h*3600+m*60+s))
    b = datetime.timedelta(0, (4*3600+0*60+0))
    #horizonrefs = [a+b,datetime.time(h+4,m ,s )] #horizonsref en datetimedelta et datetime
    horizonsrefs = date_str
    print("on a", horizonrefs)

def parse_lots_ordonnances(filename):
    '''
    Calcul des lots ordonnancés avant la date de début
    '''
    global m
    tree = ET.parse(filename)
    root = tree.getroot()
    keys = list(root[8][0].attrib.keys())
    tools = []
    d = []
    GetOrigin_Lots_Ord(filename)
    for i in range(len(root[8])):
        tools.append(root[8][i].get('ToolID'))
        d.append([root[8][i].get('ToolID'),root[8][i].get('StartDateTime')])
        
    #print(d)
    unique_tools_id = list(set(tools))
    data = dict([(key, []) for key in unique_tools_id])
    result = dict([(key, []) for key in unique_tools_id])
    occurrences = collections.Counter(tools)#contient le nombre d'occurences de chaque tool
    
    print(occurrences)
    #print(unique_tools_id)
    for i in range(len(d)):
        if(d[i][0] in unique_tools_id):
            l = d[i][1].split("T")[1]
            #print(l)
            date_time_obj = datetime.datetime.strptime(l, '%H:%M:%S.%f')
            data[d[i][0]].append(date_time_obj.time())

    final_result = dict([(key, []) for key in unique_tools_id])
    for k in data.keys():
        l = data.get(k)
        a = len(data.get(k))
        #print(l)
        for j in range(a):
            if(l[j] < horizonrefs[1]): #sélection des dates de début < horizon de référence
                result[k].append(l[j])
    #print(l)
    '''for k,v in result.items():
        print(k,v)'''


    print(horizonrefs)#horizon de ref
    '''for k,v in result.items():
        print(k,v)'''

    for k,v in result.items():
        final_result[k] = len(v)
        #print(k,v)
    
    '''for k,v in data.items():
        print(k,v)'''

    for k,v in final_result.items():
        print(k,v)
    return final_result


def GetOrigin_Lots_Taux(name, moves_windows):
    '''
    Fournit horizon de référence pour calcul du taux d'odonnancement 
     =  origine(prise dans ToolStatuses.txt) + moves_windows
    '''
    global refs
    origin = ''
    path = os.getcwd()
    fichier = name[:19] +'.txt'
    #print(fichier)
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == fichier ):
            f = open(filepath,'r')
            lines = f.readlines()
            line = lines[1] #Get the second line
            t = line.split(';') #get table of value separated by semi colon
            origin = t[4]
            f.close()
    
    date_str = origin.strip('\n')
    #print(date_str)
    h = datetime.timedelta(0, (moves_windows*3600+0*60+0))
    refs = dateutil.parser.isoparse(date_str )  + h
    print(refs)

def parse_taux(filename,moves_windows): 
    '''
    Fourni le taux de fonctionnement des machines
    '''
    global m
    tree = ET.parse(filename)
    root = tree.getroot()
    keys = list(root[8][0].attrib.keys())
    tools = []
    d = []
    GetOrigin_Lots_Taux(filename, moves_windows)  
    for i in range(len(root[8])):
        tools.append(root[8][i].get('ToolID'))
        d.append([root[8][i].get('ToolID'),root[8][i].get('StartDateTime'),root[8][i].get('EndDateTime')])

    unique_tools_id = list(set(tools))
    data = dict([(key, []) for key in unique_tools_id])
    result = dict([(key, []) for key in unique_tools_id])
    final_result = dict([(key, []) for key in unique_tools_id])
    occurrences = collections.Counter(tools)#pour savoir la taille de la liste des dates selon l'id
    for i in range(len(d)):
        if(d[i][0] in unique_tools_id):
            date_debut = dateutil.parser.isoparse(d[i][1])
            date_fin = dateutil.parser.isoparse(d[i][2])
           
            tableau = []
            tableau.append(date_debut)
            tableau.append(date_fin)
            data[d[i][0]].append(tableau)

    print(type(refs))
    for k in data.keys():
        if len(data.get(k)) == 0:
            continue     
        data[k] = sorted(data.get(k), key=lambda x: x[0])  
        debut = data.get(k)[0][0] #date origine   
        if(debut < refs):
            continuous_interval = data.get(k)[0]            
            for i in range(len(data.get(k))):
                if(continuous_interval[1] < refs):
                    continuous_interval[1] = data.get(k)[i][1]
 
                if (continuous_interval[1] > refs):
                    continuous_interval[1] = refs
                    break

                if i == 0:
                    continue                                       
                
                if(data.get(k)[i][0] < continuous_interval[1] ):                 
                    continuous_interval[1] = data.get(k)[i][1]
                    
                    
                #else:
                    #continuous_interval = data.get(k)[i]                 

            result[k].append(continuous_interval)

    taux = dict([(key, 0) for key in unique_tools_id])
    for k in result.keys():
        s = datetime.timedelta(0, (0*3600+0*60+0))
        for i in range(len(result.get(k))):
            s = s + result.get(k)[i][1] - result.get(k)[i][0]
            seconds = moves_windows*3600
            r = s.total_seconds()/ seconds            
        taux[k] = r*100 #taux en pourcentage

    for k,v in taux.items():
        print(k,v)

    for k,v in result.items():
        print(k,v)

    return taux  



def WriteResults():
    files = []
    path = os.getcwd()
    #On récupère tous les noms des extracts dans files
    for f in glob.glob("*.xlsx"):
        if(f.find('Results') == -1):
            files.append(f.strip('.xlsx'))
            
    for i in range(len(files)): 
        for filepath in pathlib.Path(path).glob('**/*'): 
            if(filepath.name.find(files[i]+ '_4h.xml')!= -1):
                o = parse_lots_ordonnances(files[i] + '4h.xml')
                t = parse_taux(files[i] + '4h.xml', 4) 
        
        Fill(files[i],o,t)  
            

    


def Fill(extract,o,t):
    '''
    Sauvegarde des résultats dans Result_Solver.xlsx
    '''
    global lignes
    lignes,tools, ids, sheets = [], [], [], []
    path = os.getcwd() 
    #print(path)
    for filepath in pathlib.Path(path).glob('**/*'): 
        #print(filepath.name)
        if(filepath.name == "Processability_"+ extract +".txt"):
            f = open(filepath,'r')
            lines = f.readlines()
            lines.remove(lines[0])
            for line in lines:
                line.strip('\n')
                list1 = line.split(';')
                #print(list1)
                ids.append(list1[2])
                #liste des outils sans doublons
            f.close()

    machines = list(set(ids))
    #print(machines)
    occurrences = collections.Counter(ids)
    workbook = openpyxl.load_workbook('result_presentation.xlsx') 
    worksheet0 = workbook.worksheets[0]
    worksheet1 = workbook.worksheets[1]
    worksheet2 = workbook.worksheets[2]
    worksheet3 = workbook.worksheets[3]
    worksheet4 = workbook.worksheets[4]
    worksheet5 = workbook.worksheets[5]
    worksheet6 = workbook.worksheets[6]
    worksheet7 = workbook.worksheets[7]

    row = worksheet.max_row
    j = 3
    #on écrit le nom des tools dans le fichier Excel
    for i in range(1,len(machines)+1):
        worksheet.cell(j , 1).value = machines[i-1]
        worksheet.cell(j , 2).value = occurrences[machines[i-1]]
        worksheet.cell(j , 3).value = o1.get(machines[i-1])
        worksheet.cell(j , 4).value = o2.get(machines[i-1])
        worksheet.cell(j , 5).value = o3.get(machines[i-1])
        worksheet.cell(j , 6).value = o4.get(machines[i-1])
        worksheet.cell(j , 7).value = o5.get(machines[i-1])
        worksheet.cell(j , 8).value = t1.get(machines[i-1])
        worksheet.cell(j , 9).value = t2.get(machines[i-1])
        worksheet.cell(j , 10).value = t3.get(machines[i-1])
        worksheet.cell(j , 11).value = t4.get(machines[i-1])
        worksheet.cell(j , 12).value = t5.get(machines[i-1])
        j = j + 1
    workbook.save('result_presentation.xlsx')


#parse_taux('Solver_20160623_16h2h.xml',2)  
#GetOrigin_Lots_Ord('Solver_20160623_16h2h.xml')
#GetOrigin_Lots_Taux('Solver_20160623_16h5h.xml', 5)
#parse_lots_ordonnances('Solver_20160623_16h2h.xml')

GetOrigin_Lots_Taux('Solver_20200709_11h4h_0_0_10_up_1.xml',4)
a = parse_taux('Solver_20200709_11h4h_0_0_10_up_1.xml',4)
'''z = parse_taux('Solver_20200709_11h4h_0_0_10_up_-10.xml',4)

b = parse_taux('Solver_20200709_11h4h_1_5_10_up_1.xml',4)
y = parse_taux('Solver_20200709_11h4h_1_5_10_up_-10.xml',4)

c = parse_taux('Solver_20200709_11h4h_1_5_100_up_1.xml',4)
k = parse_taux('Solver_20200709_11h4h_1_5_100_up_-10.xml',4)

d= parse_taux('Solver_20200709_11h4h_1_5_1000_up_1.xml',4)
l = parse_taux('Solver_20200709_11h4h_1_5_1000_up_-10.xml',4)

e= parse_taux('Solver_20200709_11h4h_1_10_100_up_1.xml',4)
m = parse_taux('Solver_20200709_11h4h_1_10_100_up_-10.xml',4)

u = parse_taux('Solver_20200709_11h4h_80_50_100_up_1.xml',4)
n = parse_taux('Solver_20200709_11h4h_80_50_100_up_-10.xml',4)

g= parse_taux('Solver_20200709_11h4h_100_80_1000_up_1.xml',4)
o = parse_taux('Solver_20200709_11h4h_100_80_1000_up_-10.xml',4)

h = parse_taux('Solver_20200709_11h4h_80_50_1000_up_1.xml',4)
p = parse_taux('Solver_20200709_11h4h_80_50_1000_up_-10.xml',4)


lignes,tools, ids, sheets = [], [], [], []
path = os.getcwd() 
#print(path)
for filepath in pathlib.Path(path).glob('**/*'): 
    #print(filepath.name)
    if(filepath.name == "Processability_Solver_20200709_11h.txt"):
        f = open(filepath,'r')
        lines = f.readlines()
        lines.remove(lines[0])
        for line in lines:
            line.strip('\n')
            list1 = line.split(';')
            #print(list1)
            ids.append(list1[2])
            #liste des outils sans doublons
        f.close()

machines = list(set(ids))
#print(machines)
occurrences = collections.Counter(ids)
workbook = openpyxl.load_workbook('Results_Solver_20200709_11h.xlsx') 
worksheet0 = workbook.worksheets[0]
worksheet1 = workbook.worksheets[1]
worksheet2 = workbook.worksheets[2]
worksheet3 = workbook.worksheets[3]
worksheet4 = workbook.worksheets[4]
worksheet5 = workbook.worksheets[5]
worksheet6 = workbook.worksheets[6]
worksheet7 = workbook.worksheets[7]

row = worksheet0.max_row
j = 2
#on écrit le nom des tools dans le fichier Excel
for i in range(1,len(machines)+1):
    worksheet0.cell(j , 1).value = machines[i-1]
    worksheet0.cell(j , 2).value = occurrences[machines[i-1]]
    worksheet0.cell(j , 3).value = a.get(machines[i-1])
    worksheet0.cell(j , 4).value = z.get(machines[i-1])

    worksheet1.cell(j , 1).value = machines[i-1]
    worksheet1.cell(j , 2).value = occurrences[machines[i-1]]
    worksheet1.cell(j , 3).value = b.get(machines[i-1])
    worksheet1.cell(j , 4).value = y.get(machines[i-1])

    worksheet2.cell(j , 1).value = machines[i-1]
    worksheet2.cell(j , 2).value = occurrences[machines[i-1]]
    worksheet2.cell(j , 3).value = c.get(machines[i-1])
    worksheet2.cell(j , 4).value = k.get(machines[i-1])

    worksheet3.cell(j , 1).value = machines[i-1]
    worksheet3.cell(j , 2).value = occurrences[machines[i-1]]
    worksheet3.cell(j , 3).value = d.get(machines[i-1])
    worksheet3.cell(j , 4).value = l.get(machines[i-1])

    worksheet4.cell(j , 1).value = machines[i-1]
    worksheet4.cell(j , 2).value = occurrences[machines[i-1]]
    worksheet4.cell(j , 3).value = e.get(machines[i-1])
    worksheet4.cell(j , 4).value = m.get(machines[i-1])

    worksheet5.cell(j , 1).value = machines[i-1]
    worksheet5.cell(j , 2).value = occurrences[machines[i-1]]
    worksheet5.cell(j , 3).value = u.get(machines[i-1])
    worksheet5.cell(j , 4).value = n.get(machines[i-1])

    worksheet6.cell(j , 1).value = machines[i-1]
    worksheet6.cell(j , 2).value = occurrences[machines[i-1]]
    worksheet6.cell(j , 3).value = g.get(machines[i-1])
    worksheet6.cell(j , 4).value = o.get(machines[i-1])

    worksheet7.cell(j , 1).value = machines[i-1]
    worksheet7.cell(j , 2).value = occurrences[machines[i-1]]
    worksheet7.cell(j , 3).value = h.get(machines[i-1])
    worksheet7.cell(j , 4).value = p.get(machines[i-1])

    j = j + 1
workbook.save('Results_Solver_20200709_11h.xlsx')'''





import os
import pathlib
import openpyxl
import xlsxwriter



def ExistsExcel(ExcelFile):
    """
    Return True if an Excel file of the selected zip already exists
    Return False otherwise
    """
    exists = False
    path = os.getcwd()
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == ExcelFile):
            exists = True
            return exists
        else:
            exists = False
    return exists



def ExcelTemplate(name):
    """
    Create the template to stock the values the values of each parameter which can be modified for the simulation
    """
    #Excel file creation
    #name = Code.SelectInputData() déjà en xlsx

    workbook = xlsxwriter.Workbook(name)
    worksheet1 = workbook.add_worksheet("SOLVING_DURATION_IN_SECONDS")
    worksheet2 = workbook.add_worksheet("MOVES_WINDOW_IN_HOURS")
    worksheet3 = workbook.add_worksheet("MULTICRITERIA_MODE") 
    worksheet4 = workbook.add_worksheet("PRIORITY_LOTS")
    worksheet5 = workbook.add_worksheet("TARGET_FREQUENCY")

    #Write indicators in all worksheets
    worksheet1.write('A1', 'Solving_duration') 
    worksheet1.write('B1', 'X_factor') 
    worksheet1.write('C1', 'Number of moves')
    worksheet1.write('D1', 'TargetSatisfaction') 
    worksheet1.write('E1', 'MasksTransfers') 
    worksheet1.write('F1', 'Wip') 
    worksheet1.write('G1', 'Temperature Change Duration') 
    
    worksheet2.write('A1', 'Moves_Window') 
    worksheet2.write('B1', 'X_factor') 
    worksheet2.write('C1','Number of moves')
    worksheet2.write('D1', 'TargetSatisfaction') 
    worksheet2.write('E1', 'MasksTransfers') 

    worksheet3.write('A1','Moves')
    worksheet3.write('B1','Cycletime')
    worksheet3.write('C1','TargetSatisfactionIndicator')
    worksheet3.write('D1', 'X_factor') 
    worksheet3.write('E1', 'Number of moves')
    worksheet3.write('F1', 'TargetSatisfaction')
    worksheet3.write('G1', 'MasksTransfers') 
   
    worksheet4.write('A1','High_priority')
    worksheet4.write('B1','Medium_priority')
    worksheet4.write('C1','Low_priority')
    worksheet4.write('D1', 'X_factor') 
    worksheet4.write('E1', 'Number of moves')
    worksheet4.write('F1', 'TargetSatisfaction') 
    worksheet4.write('G1', 'MasksTransfers')
   
    worksheet5.write('A1','Focus_moves')
    worksheet5.write('B1','Shift_online')
    worksheet5.write('C1', 'X_factor') 
    worksheet5.write('D1', 'Number of moves')
    worksheet5.write('E1', 'TargetSatisfaction') 
    worksheet5.write('F1', 'MasksTransfers') 


    #Close Workbook
    workbook.close() 
    return workbook
        

'''def Edit(ExcelFileName):
    workbook = openpyxl.load_workbook(ExcelFileName) 
    worksheet0 = workbook.worksheets[0]
    row = worksheet0.max_row
    worksheet0.cell(row + 1, 1).value = 456
    workbook.save(ExcelFileName)
        
def Edit(ExcelFileName, ParametersValues, ResultValues):
    workbook = openpyxl.load_workbook(ExcelFileName) 
   
    #Writing Parameters
                        #SolvingDuration
    worksheet0 = workbook.worksheets[0]
    row = worksheet0.max_row
    worksheet0.cell(row+1 , 1).value = ParametersValues[0]
    #Writing simulation results
    worksheet0.cell(row+1, 2).value = ResultValues[0]
    worksheet0.cell(row+1 , 3).value = ResultValues[1]
    worksheet0.cell(row+1, 4).value = ResultValues[2]

                        #MovesWindowInHours 
    worksheet1 = workbook.worksheets[1]    
    worksheet1.cell(row+1 , 1).value = ParametersValues[2]
        #Writing simulation results
    worksheet1.cell(row+1, 2).value = ResultValues[0]
    worksheet1.cell(row+1, 3).value = ResultValues[1]
    worksheet1.cell(row+1, 4).value = ResultValues[2]

                        #MulticriteriaMode
    worksheet2 = workbook.worksheets[2]    
    worksheet2.cell(row+1, 1).value = ParametersValues[3]#moves
    worksheet2.cell(row+1, 2).value = ParametersValues[4]#cycletime
    worksheet2.cell(row+1, 3).value = ParametersValues[5]#tsi
    #Writing simulation results
    worksheet2.cell(row+1, 4).value = ResultValues[0]
    worksheet2.cell(row+1, 5).value = ResultValues[1]
    worksheet2.cell(row+1, 6).value = ResultValues[2]

                        #PriorityLots
    worksheet3 = workbook.worksheets[3]    
    worksheet3.cell(row+1, 1).value = ParametersValues[7]#high
    worksheet3.cell(row+1, 2).value = ParametersValues[8]#medium
    worksheet3.cell(row+1, 3).value = ParametersValues[9]#low
        #Writing simulation results
    worksheet3.cell(row+1, 4).value = ResultValues[0]
    worksheet3.cell(row+1, 5).value = ResultValues[1]
    worksheet3.cell(row+1, 6).value = ResultValues[2]

                        #TargetFrequency
    worksheet4 = workbook.worksheets[4]   
    worksheet4.cell(row+1 , 1).value = ParametersValues[10]#focus
    worksheet4.cell(row+1 , 2).value = ParametersValues[11]#shift
        #Writing simulation results
    worksheet4.cell(row+1 , 3).value = ResultValues[0]
    worksheet4.cell(row+1 , 4).value = ResultValues[1]
    worksheet4.cell(row+1 , 5).value = ResultValues[2]

    workbook.save(ExcelFileName)'''

'''
Find the Wip level of the solver extract
'''
def GetWip():
    path = os.getcwd() 
    wips = []
    #print(path)
    for filepath in pathlib.Path(path).glob('**/*'): 
        #print(filepath.name)
        if(filepath.name == "Lots.txt"):
            f = open(filepath,'r')
            lines = f.readlines()
            for i in range(1,len(lines)):
                ligne = lines[i].split(';')
                wips.append(int(ligne[3])) 
                  
            f.close()
    return sum(wips)

def GetTemperatureDuration():
    path = os.getcwd() 
    temps = []
    #print(path)
    for filepath in pathlib.Path(path).glob('**/*'): 
        #print(filepath.name)
        if(filepath.name == "Processability.txt"):
            f = open(filepath,'r')
            lines = f.readlines()
            for i in range(1,len(lines)):
                ligne = lines[i].split(';')
                if(ligne[7] != "" and ligne[7]!="\n"):
                    temps.append(int(ligne[7])) 
                  
            f.close()
    return sum(temps)


def Edit(ExcelFileName,ParametersValues, ResultValues):
    if(ExistsExcel(ExcelFileName) == True):   
        workbook = openpyxl.load_workbook(ExcelFileName) 
        #Writing Parameters
                            #SolvingDuration
        worksheet0 = workbook.worksheets[0]
        row = worksheet0.max_row
        worksheet0.cell(row+1 , 1).value = ParametersValues[0]
        #Writing simulation results
        worksheet0.cell(row+1, 2).value = ResultValues[0]
        worksheet0.cell(row+1 , 3).value = ResultValues[1]
        worksheet0.cell(row+1, 4).value = ResultValues[2]
        worksheet0.cell(row+1, 5).value = ResultValues[3]
        worksheet0.cell(row+1 , 6).value = GetWip() #Write the Wip level of the simulation
        #worksheet0.cell(row+1 , 7).value = GetTemperatureDuration()
        #worksheet0.cell(row+1, 8).value = ResultValues[4]

                            #MovesWindowInHours 
        worksheet1 = workbook.worksheets[1]  
        worksheet1.cell(row+1 , 1).value = ParametersValues[2]
            #Writing simulation results
        worksheet1.cell(row+1, 2).value = ResultValues[0]
        worksheet1.cell(row+1, 3).value = ResultValues[1]
        worksheet1.cell(row+1, 4).value = ResultValues[2]
        worksheet1.cell(row+1, 5).value = ResultValues[3]
        #worksheet1.cell(row+1, 7).value = ResultValues[4]

                            #MulticriteriaMode
        worksheet2 = workbook.worksheets[2]  
        worksheet2.cell(row+1, 1).value = ParametersValues[3]#moves
        worksheet2.cell(row+1, 2).value = ParametersValues[4]#cycletime
        worksheet2.cell(row+1, 3).value = ParametersValues[5]#tsi
            #Writing simulation results
        worksheet2.cell(row+1, 4).value = ResultValues[0]
        worksheet2.cell(row+1, 5).value = ResultValues[1]
        worksheet2.cell(row+1, 6).value = ResultValues[2]
        worksheet2.cell(row+1, 7).value = ResultValues[3]
        #worksheet2.cell(row+1, 9).value = ResultValues[4]

                            #PriorityLots
        worksheet3 = workbook.worksheets[3]    
        worksheet3.cell(row+1, 1).value = ParametersValues[7]#high
        worksheet3.cell(row+1, 2).value = ParametersValues[8]#medium
        worksheet3.cell(row+1, 3).value = ParametersValues[9]#low
            #Writing simulation results
        worksheet3.cell(row+1, 4).value = ResultValues[0]
        worksheet3.cell(row+1, 5).value = ResultValues[1]
        worksheet3.cell(row+1, 6).value = ResultValues[2]
        worksheet3.cell(row+1, 7).value = ResultValues[3]
        #worksheet3.cell(row+1, 9).value = ResultValues[4]

                            #TargetFrequency
        worksheet4 = workbook.worksheets[4]   
        worksheet4.cell(row+1 , 1).value = ParametersValues[10]#focus
        worksheet4.cell(row+1 , 2).value = ParametersValues[11]#shift
            #Writing simulation results
        worksheet4.cell(row+1 , 3).value = ResultValues[0]
        worksheet4.cell(row+1 , 4).value = ResultValues[1]
        worksheet4.cell(row+1 , 5).value = ResultValues[2]
        worksheet4.cell(row+1, 6).value = ResultValues[3]
        #worksheet4.cell(row+1, 8).value = ResultValues[4]

        workbook.save(ExcelFileName)
    
    if(ExistsExcel(ExcelFileName) == False):  
        ExcelTemplate(ExcelFileName)
        workbook = openpyxl.load_workbook(ExcelFileName) 
    
        #Writing Parameters
                            #SolvingDuration
        worksheet0 = workbook.worksheets[0]
        row = worksheet0.max_row
        #worksheet0.cell(row+1 , 1).value = GetWip() #Write the Wip level of the simulation
        #worksheet0.cell(row+1 , 2).value = GetTemperatureDuration() #Write the duration of the temperature changes
        worksheet0.cell(row+1 , 1).value = ParametersValues[0]
        #Writing simulation results
        worksheet0.cell(row+1, 2).value = ResultValues[0]
        worksheet0.cell(row+1 , 3).value = ResultValues[1]
        worksheet0.cell(row+1, 4).value = ResultValues[2]
        worksheet0.cell(row+1, 5).value = ResultValues[3]
        #worksheet0.cell(row+1, 8).value = ResultValues[4]

                            #MovesWindowInHours 
        worksheet1 = workbook.worksheets[1]
        worksheet1.cell(row+1 , 1).value = ParametersValues[2]
            #Writing simulation results
        worksheet1.cell(row+1, 2).value = ResultValues[0]
        worksheet1.cell(row+1, 3).value = ResultValues[1]
        worksheet1.cell(row+1, 4).value = ResultValues[2]
        worksheet1.cell(row+1, 5).value = ResultValues[3]
        #worksheet1.cell(row+1, 6).value = ResultValues[4]

                            #MulticriteriaMode
        worksheet2 = workbook.worksheets[2]   
        worksheet2.cell(row+1, 1).value = ParametersValues[3]#moves
        worksheet2.cell(row+1, 2).value = ParametersValues[4]#cycletime
        worksheet2.cell(row+1, 3).value = ParametersValues[5]#tsi
        #Writing simulation results
        worksheet2.cell(row+1, 4).value = ResultValues[0]
        worksheet2.cell(row+1, 5).value = ResultValues[1]
        worksheet2.cell(row+1, 6).value = ResultValues[2]
        worksheet2.cell(row+1, 7).value = ResultValues[3]
        #worksheet2.cell(row+1, 8).value = ResultValues[4]

                            #PriorityLots
        worksheet3 = workbook.worksheets[3]    
        worksheet3.cell(row+1, 1).value = ParametersValues[7]#high
        worksheet3.cell(row+1, 2).value = ParametersValues[8]#medium
        worksheet3.cell(row+1, 3).value = ParametersValues[9]#low
            #Writing simulation results
        worksheet3.cell(row+1, 4).value = ResultValues[0]
        worksheet3.cell(row+1, 5).value = ResultValues[1]
        worksheet3.cell(row+1, 6).value = ResultValues[2]
        worksheet3.cell(row+1, 7).value = ResultValues[3]
        #worksheet3.cell(row+1, 8).value = ResultValues[4]


                            #TargetFrequency
        worksheet4 = workbook.worksheets[4]   
        worksheet4.cell(row+1 , 1).value = ParametersValues[10]#focus
        worksheet4.cell(row+1 , 2).value = ParametersValues[11]#shift
            #Writing simulation results
        worksheet4.cell(row+1 , 3).value = ResultValues[0]
        worksheet4.cell(row+1 , 4).value = ResultValues[1]
        worksheet4.cell(row+1 , 5).value = ResultValues[2]
        worksheet4.cell(row+1, 6).value = ResultValues[3]
        #worksheet4.cell(row+1, 7).value = ResultValues[4]

        workbook.save(ExcelFileName)




#Edit('Solver_20160623_16h.xlsx',[3,'none',1,1,1,1,1,1,7,8,9,10,'yes',';'],[7, 8, 9])

#print(GetTemperatureDuration())
import os
import re
import glob
import pathlib
import pandas as pd
import openpyxl 
import xlsxwriter
import collections
import datetime
import xml.etree.ElementTree as ET


def FindSolutionPath():
    path = os.getcwd()
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == "result_presentation.xlsx" ):
            f = filepath
    return f

def GetOrigin():
    global horizonrefs
    global date_ref 
    origin = ''
    path = os.getcwd()
    for filepath in pathlib.Path(path).glob('**/*'): 
        #print(filepath.name)
        if(filepath.name == "ToolStatuses.txt"):
            f = open(filepath,'r')
            lines = f.readlines()
            line = lines[1] #Get the second line
            t = line.split(';') #get table of value separated by semi colon
            origin = t[4]
            f.close()
    date_str = origin.strip('\n')
    date_time_obj = datetime.datetime.strptime(date_str, '%Y-%m-%d %H:%M:%S')
    t = date_time_obj.time()
    h = int(t.hour)
    m = int(t.minute)
    s = int(t.second)
    hours = datetime.time(h,0,0)
    a = datetime.timedelta(0, (h*3600+m*60+s))
    b = datetime.timedelta(0, (4*3600+0*60+0))
    horizonrefs = [a+b,datetime.time(h+4,m ,s )] #horizonsref en datetimedelta et datetime
    #print(horizonrefs)

def helping(file):
    global m
    tree = ET.parse(file)
    root = tree.getroot()
    keys = list(root[8][0].attrib.keys())
    tools = []
    d = []
    GetOrigin(h) 
    for i in range(len(root[8])):
        tools.append(root[8][i].get('ToolID'))
        d.append([root[8][i].get('ToolID'),root[8][i].get('EndDateTime')])
        
    #print(d)
    unique_tools_id = list(set(tools))
    data = dict([(key, []) for key in unique_tools_id])
    Big_data = dict([(key, []) for key in unique_tools_id])
    occurrences = collections.Counter(tools)#pour savoir la taille de la liste des dates selon l'id
    #print(occurrences)
    #print(unique_tools_id)
    for i in range(len(d)):
        if(d[i][0] in unique_tools_id):
            l = d[i][1].split("T")[1]
            #print(l)
            date_time_obj = datetime.datetime.strptime(l, '%H:%M:%S.%f')
            data[d[i][0]].append(date_time_obj.time())
    maxs = dict([(key, []) for key in unique_tools_id])
    m = 0
    for i in range(len(unique_tools_id)):
        l = data.get(unique_tools_id[i])
        fin = max(l)
        maxs[unique_tools_id[i]] = fin
    #for k, v in maxs.items():
        #print(maxs)
    
    return maxs


def parse_sum(file,moves_windows): #à modifier
    global m
    tree = ET.parse(file)
    root = tree.getroot()
    keys = list(root[8][0].attrib.keys())
    tools = []
    d = []
    GetOrigin() 
    for i in range(len(root[8])):
        tools.append(root[8][i].get('ToolID'))
        d.append([root[8][i].get('ToolID'),root[8][i].get('StartDateTime'),root[8][i].get('EndDateTime')])

    unique_tools_id = list(set(tools))
    data = dict([(key, []) for key in unique_tools_id])
    Big_data = dict([(key, []) for key in unique_tools_id])
    result = dict([(key, []) for key in unique_tools_id])
    occurrences = collections.Counter(tools)#pour savoir la taille de la liste des dates selon l'id

    for i in range(len(d)):
        if(d[i][0] in unique_tools_id):
            l1 = d[i][1].split("T")[1]
            l2 = d[i][2].split("T")[1]
            #print(l)
            date_time_obj1 = datetime.datetime.strptime(l1, '%H:%M:%S.%f')
            date_time_obj2 = datetime.datetime.strptime(l2, '%H:%M:%S.%f')
            t1 = date_time_obj1.time()
            t2 = date_time_obj2.time()
            h1 = int(t1.hour)
            m1 = int(t1.minute)
            s1 = int(t1.second)
            
            h2 = int(t2.hour)
            m2 = int(t2.minute)
            s2 = int(t2.second)
            
            d1 = datetime.timedelta(0, (h1*3600+m1*60+s1))
            d2 = datetime.timedelta(0, (h2*3600+m2*60+s2))
   
            if(date_time_obj2.time() <= horizonrefs[1]):
                tableau = [date_time_obj1, date_time_obj2]    
                if(d2 > d1):
                    data[d[i][0]].append(d2-d1)
                if(d2 < d1):
                    a = datetime.timedelta(seconds = (d2 - d1).seconds/3600)
                    data[d[i][0]].append(a)
                
    
    for k,v in data.items():
        result[k] = sum(data.get(k), datetime.timedelta())

    #print(horizonrefs[0].total_seconds())
    final_result = dict([(key, []) for key in unique_tools_id])
    for k,v in result.items():
        print(k,v.total_seconds(),horizonrefs[0].total_seconds())
        final_result[k] = v.total_seconds()/(horizonrefs[0].total_seconds())

    '''for k,v in final_result.items():
        print(k,v)'''
    return final_result   

def parse_minimum(file):
    global m
    tree = ET.parse(file)
    root = tree.getroot()
    keys = list(root[8][0].attrib.keys())
    tools = []
    d = []
    GetOrigin() 
    for i in range(len(root[8])):
        tools.append(root[8][i].get('ToolID'))
        d.append([root[8][i].get('ToolID'),root[8][i].get('StartDateTime')])
        
    #print(d)
    unique_tools_id = list(set(tools))
    data = dict([(key, []) for key in unique_tools_id])
    Big_data = dict([(key, []) for key in unique_tools_id])
    result = dict([(key, []) for key in unique_tools_id])
    occurrences = collections.Counter(tools)#pour savoir la taille de la liste des dates selon l'id
    
    print(occurrences)
    print(unique_tools_id)
    for i in range(len(d)):
        if(d[i][0] in unique_tools_id):
            l = d[i][1].split("T")[1]
            #print(l)
            date_time_obj = datetime.datetime.strptime(l, '%H:%M:%S.%f')
            data[d[i][0]].append(date_time_obj.time())

    final_result = dict([(key, []) for key in unique_tools_id])
    for k in data.keys():
        l = data.get(k)
        a = len(data.get(k))
        print(l)
        for j in range(a):
            if(l[j] < horizonrefs[1]):
                result[k].append(l[j])


    #print(l)
    '''for k,v in result.items():
        print(k,v)'''


    print(horizonrefs)#horizon de ref
    for k,v in result.items():
        print(k,v)

    for k,v in result.items():
        final_result[k] = len(v)
        print(k,v)
    
    for k,v in data.items():
        print(k,v)

    for k,v in final_result.items():
        print(k,v)
    return final_result



def WriteResults(extract):
    files = []
    for f in glob.glob("*.xml"):
        files.append(f)
    for i in range(len(files)):       
        if(files[i].find(extract + '2h.xml')!= -1):
            o1 = parse_minimum(extract + '2h.xml')
            t1 = parse_sum(extract + '2h.xml')
        if (files[i].find(extract + '3h.xml')!= -1):
            o2 = parse_minimum(extract + '3h.xml') 
            t2 = parse_sum(extract + '3h.xml')
        if(files[i].find(extract + '4h.xml')!= -1 ):
            o3 = parse_minimum(extract + '4h.xml')
            t3 = parse_sum(extract + '4h.xml') 
        if(files[i].find(extract + '5h.xml')!= -1):
           o4 = parse_minimum(extract + '5h.xml')
           t4 = parse_sum(extract + '5h.xml')
        if (files[i].find(extract + '6h.xml')!= -1):
           o5 = parse_minimum(extract + '6h.xml')
           t5 = parse_sum(extract + '6h.xml')

    Fill(extract,o1,o2,o3,o4,o5,t1,t2,t3,t4,t5)  
            


def Fill(extract,
o1,o2,o3,o4,o5,
t1,t2,t3,t4,t5):
    global lignes
    lignes,tools, ids, sheets = [], [], [], []
    path = os.getcwd() 
    #print(path)
    for filepath in pathlib.Path(path).glob('**/*'): 
        #print(filepath.name)
        if(filepath.name == "Processability.txt"):
            f = open(filepath,'r')
            lines = f.readlines()
            lines.remove(lines[0])
            for line in lines:
                line.strip('\n')
                list1 = line.split(';')
                #print(list1)
                ids.append(list1[2])
                #liste des outils sans doublons
            f.close()

    machines = list(set(ids))
    print(machines)
    occurrences = collections.Counter(ids)
    workbook = openpyxl.load_workbook('result_presentation.xlsx') 
    sheets = workbook.sheetnames
    i = sheets.index(extract)
    worksheet = workbook.worksheets[i]
    row = worksheet.max_row
    j = 3
    #on écrit le nom des tools dans le fichier Excel
    for i in range(1,len(machines)+1):
        worksheet.cell(j , 1).value = machines[i-1]
        worksheet.cell(j , 2).value = occurrences[machines[i-1]]
        worksheet.cell(j , 3).value = o1.get(machines[i-1])
        worksheet.cell(j , 4).value = o2.get(machines[i-1])
        worksheet.cell(j , 5).value = o3.get(machines[i-1])
        worksheet.cell(j , 6).value = o4.get(machines[i-1])
        worksheet.cell(j , 7).value = o5.get(machines[i-1])
        worksheet.cell(j , 8).value = t1.get(machines[i-1])
        worksheet.cell(j , 9).value = t2.get(machines[i-1])
        worksheet.cell(j , 10).value = t3.get(machines[i-1])
        worksheet.cell(j , 11).value = t4.get(machines[i-1])
        worksheet.cell(j , 12).value = t5.get(machines[i-1])
        j = j + 1
    workbook.save('result_presentation.xlsx')


parse_minimum('Solver_20160623_16h4h.xml')     
#parse_sum('Solver_20160623_16h2h.xml',2)     
#Fill('Solver_20160624_8h')
#WriteResults('Solver_20160623_16h')
#WriteResults('Solver_20160623_17h')
#WriteResults('Solver_20160624_8h')
#WriteResults('Solver_20160624_9h')
#WriteResults('Solver_20160627_8h')
#WriteResults('Solver_20160627_9h')
#WriteResults('Solver_20160627_10h')
#WriteResults('Solver_20160627_11h')
#WriteResults('Solver_20160627_12h')
#WriteResults('Solver_20160627_15h')
#WriteResults('Solver_20160627_16h')
#WriteResults('Solver_20200703_14h45')
#WriteResults('Solver_20200709_11h')

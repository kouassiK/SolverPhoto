import os
import glob
import pathlib


files = []
for f in glob.glob("*.xlsx"):
        if(f != 'result_presentation.xlsx'):
            files.append(f.strip('.xlsx'))
            
for i in range(len(files)): 
    path = os.getcwd()
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name.find(files[i]+ '2h.xml')!= -1):
                print(files[i]+ '2h.xml')
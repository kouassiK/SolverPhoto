def parse_minimum(file):
    global m
    tree = ET.parse(file)
    root = tree.getroot()
    keys = list(root[8][0].attrib.keys())
    tools = []
    d = []
    GetOrigin() 
    for i in range(len(root[8])):
        tools.append(root[8][i].get('ToolID'))
        d.append([root[8][i].get('ToolID'),root[8][i].get('EndDateTime')])
        
    #print(d)
    unique_tools_id = list(set(tools))
    data = dict([(key, []) for key in unique_tools_id])
    Big_data = dict([(key, []) for key in unique_tools_id])
    occurrences = collections.Counter(tools)#pour savoir la taille de la liste des dates selon l'id
    #print(occurrences)
    #print(unique_tools_id)
    for i in range(len(d)):
        if(d[i][0] in unique_tools_id):
            l = d[i][1].split("T")[1]
            #print(l)
            date_time_obj = datetime.datetime.strptime(l, '%H:%M:%S.%f')
            data[d[i][0]].append(date_time_obj.time())
    minimums = dict([(key, []) for key in unique_tools_id])
    m = 0
    for i in range(len(unique_tools_id)):
        l = data.get(unique_tools_id[i])
        fin = max(l)
        #print(unique_tools_id[i], fin)
        if((fin <= horizonrefs[1]) == True):
            m = m + 1
            minimums[unique_tools_id[i] ]= fin

    for k,v in data.items():
        print(k,v)
    
    for k,v in minimums.items():
        print(k,v)
    #print((occurrences))
    print(m) #m = le nombre qui finit avant l'horizonref '''
    return m

t1 = date_time_obj1.time()
                t2 = date_time_obj2.time()

                h1 = int(t1.hour)
                m1 = int(t1.minute)
                s1 = int(t1.second)
                
                h2 = int(t2.hour)
                m2 = int(t2.minute)
                s2 = int(t2.second)
                
                d1 = datetime.timedelta(0, (h1*3600+m1*60+s1))
                d2 = datetime.timedelta(0, (h2*3600+m2*60+s2))
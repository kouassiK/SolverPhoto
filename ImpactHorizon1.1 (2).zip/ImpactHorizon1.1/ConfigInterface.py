import os
import Code
import shutil
import test
import Excel
import pathlib
from tkinter import *
import xlsxwriter
import ConfigInterface
import xml.etree.ElementTree as ET



def MoveSolution():
    """
    Return True if an Excel file of the selected zip already exists
    Return False otherwise
    """
    exists = False
    path = os.getcwd()
    print(path)
    for filepath in pathlib.Path(path).glob('**/*'): 
        #print(filepath.name)
        if(filepath.name == "Solution.xml"):
            print(filepath, path)
            real_dst = os.path.join(path, os.path.basename(filepath))
            shutil.move(filepath,real_dst)
            print("b")


def getValues():
    elem1 = solving_duration.get()
    elem2 = origin_schedule.get()
    elem3 = moves_window.get()
    elem4 = weight_moves.get()
    elem5 = weight_cycletime.get()
    elem6 = weight_tsi.get()
    elem7 = alpha_tsi.get()
    elem8 = weight_high_priority.get()
    elem9 = weight_medium_priority.get()
    elem10 = weight_low_priority.get()
    elem11 = weight_focus.get()
    elem12 = weight_shiftonline.get()
    elem13 = skip_hold.get()
    elem14 = files_separator.get()

    #print(elem1, elem2, elem3, elem4,elem5,elem6,elem7,elem8,elem9,elem10,elem11,elem12,elem13,elem14)
    result = [elem1, elem2, elem3, elem4,elem5,elem6,elem7,elem8,elem9,elem10,elem11,elem12,elem13,elem14]

    """
    Edit the Config file with the new parameters(in newParameters) entered in the the form
    """
    path = os.getcwd()
    lst = []
    newParameters = ["input","output","parameters.parameters.xml"] + result
    i = 0
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == "Config" ):
            f = open(filepath,'r')
            for line in f:
                line = line.replace(line.partition("=")[2],newParameters[i]) 
                lst.append(line)
                i = i + 1
            f.close()
            f = open("Config","w")
            for line in lst:
                f.write(line + "\n")
            f.close()
            """
            Wait until Config is closed to launch the simulation
            """
            
            Code.MoveINData()
            Code.MoveModelData()
            Code.commandPrompt()
            """
            Edit the Excel file with the new parameters

            """
            Code.MoveBackModelData()

            test.MoveSolution()
            ExcelFileName = Code.p
            ParametersValues = result
            f = test.FindSolutionPath()
            #print(f)
            ResultValues = test.SaveValues(f)
            name = ExcelFileName + '.xlsx'
            #print(ExcelFileName)
            Excel.Edit(name , ParametersValues , ResultValues)



root = Tk()
root.geometry('600x900')
root.title("Config Form")


solving_duration = IntVar()
origin_schedule = StringVar()
moves_window = IntVar()
weight_moves = IntVar()
weight_cycletime = IntVar()
weight_tsi = IntVar()
alpha_tsi = IntVar()
weight_high_priority = IntVar()
weight_medium_priority = IntVar()
weight_low_priority = IntVar()
weight_focus = IntVar()
weight_shiftonline = IntVar()
skip_hold = StringVar()
files_separator = StringVar()


label_2 = Label(root, text="SOLVING_DURATION_IN_SECONDS",width=60,font=("bold", 8))
label_2.place(x=-99,y=50)
solving_duration = Entry(root)
solving_duration.place(x=260,y=50)

label_3 = Label(root, text="ORIGIN_OF_THE_SCHEDULE",width=60,font=("bold", 8))
label_3.place(x=-110,y=100)
origin_schedule = Entry(root)
origin_schedule.place(x=260,y=100)

label_4 = Label(root, text="MOVES_WINDOW_IN_HOURS",width=60,font=("bold", 8))
label_4.place(x=-110,y=150)
moves_window= Entry(root)
moves_window.place(x=260,y=150)

label_5 = Label(root, text="WEIGHT_OF_MOVES",width=60,font=("bold", 8))
label_5.place(x=-130,y=200)
weight_moves = Entry(root)
weight_moves.place(x=260,y=200)

label_6 = Label(root, text="WEIGHT_OF_CYCLETIME",width=60,font=("bold", 8))
label_6.place(x=-120,y=250)
weight_cycletime = Entry(root)
weight_cycletime.place(x=260,y=250)

label_7 = Label(root, text="WEIGHT_OF_TargetSatisfactionIndicator",width=70,font=("bold", 8))
label_7.place(x=-110,y=300)
weight_tsi = Entry(root)
weight_tsi.place(x=260,y=300)

label_8 = Label(root, text="ALPHA_FOR_TARGET_SATISFACTION_INDICATOR",width=80,font=("bold", 8))
label_8.place(x=-108,y=350)
alpha_tsi = Entry(root)
alpha_tsi.place(x=260,y=350)

label_9 = Label(root, text="WEIGHT_FOR_HIGH_PRIORITY_LOTS",width=60,font=("bold", 8))
label_9.place(x=-90,y=400)
weight_high_priority = Entry(root)
weight_high_priority.place(x=260,y=400)

label_10 = Label(root, text="WEIGHT_FOR_MEDIUM_PRIORITY_LOTS",width=60,font=("bold", 8))
label_10.place(x=-80,y=450)
weight_medium_priority = Entry(root)
weight_medium_priority.place(x=260,y=450)

label_11 = Label(root, text="WEIGHT_FOR_LOW_PRIORITY_LOTS",width=60,font=("bold", 8))
label_11.place(x=-90,y=500)
weight_low_priority = Entry(root)
weight_low_priority.place(x=260,y=500)

label_12 = Label(root, text="WEIGHT_FOR_FOCUS_MOVES",width=60,font=("bold", 8))
label_12.place(x=-100,y=550)
weight_focus = Entry(root)
weight_focus.place(x=260,y=550)


label_13 = Label(root, text="WEIGHT_FOR_SHIFTONLINE_MOVES",width=80,font=("bold", 8))
label_13.place(x=-140,y=600)
weight_shiftonline = Entry(root)
weight_shiftonline.place(x=260,y=600)

label_14 = Label(root, text="SKIP_HOLD",width=60,font=("bold", 8))
label_14.place(x=-110,y=650)
skip_hold = Entry(root)
skip_hold.place(x=260,y=650)

label_15 = Label(root, text="INPUT_FILES_VALUES_SEPARATOR",width=70,font=("bold", 8))
label_15.place(x=-110,y=700)
files_separator = Entry(root)
files_separator.place(x=260,y=700)


Button(root, text='Submit',width=20,bg='brown',fg='white',command = getValues).place(x=200,y=750)


root.mainloop()


import os
import shutil
import pathlib
import zipfile
import subprocess as sbp
import tkinter as tkinter
from zipfile import ZipFile
from distutils.dir_util import copy_tree
from tkinter.filedialog import askdirectory
from tkinter.filedialog import askopenfilename
from tkinter.filedialog import askopenfile

p = " "

def SelectSolverDataZip():
    """
    Select the path to the data's folder to unzip
    Return the name of the zip folder
    """
    global p
    tkinter.Tk().withdraw()
    path = askopenfile()
    #print(path.name.strip('.zip'))
    #p = os.path.basename(path)
    #print(path.name)
    p = os.path.basename(path.name.strip('.zip'))
    return path.name

def UnzipSolverData():
    """
    Unzip the zip file (argument) in the current directory
    """
    filename = SelectSolverDataZip()
    with ZipFile(filename, 'r') as zip:
        zip.printdir()
        zip.extractall()
        
    return filename

def RenameUnzippedSolverData():
    """
    Rename the unzipped Solver data to IN
    """
    current_directory = os.getcwd()
    old_path = UnzipSolverData().strip('.zip')#to get the path without the .zip 
    print(old_path)
    filename = os.path.join(current_directory,os.path.basename(old_path))
    
    #Create path name for input folder
    IN = os.path.join(current_directory,r'IN')
    os.rename(filename,IN)
    return IN



##################################################################################################

def CreateFolders():
    """
    Create input and output folders which contain the data and the result of each run of the simulation
    Return input path
    """
    
    current_directory = os.getcwd()
    #Create path name for input folder
    input_folder = os.path.join(current_directory,r'input')
    #Create path name for output folder
    output_folder = os.path.join(current_directory,r'output')
    #Create output_folder if they don't exist
    if not os.path.exists(output_folder) and not os.path.exists(input_folder):
        #Create input_folder and output_folder
        os.makedirs(input_folder)
        os.makedirs(output_folder)
    else:
        #delete input folder
        shutil.rmtree(input_folder)
        #delete output folder
        shutil.rmtree(output_folder)
        #Recreate input_folder and output_folder
        os.makedirs(input_folder)
        os.makedirs(output_folder)
    
    return input_folder
        

def FindModelData():   
    """
    Find ModelData folder path
    """
    #Check all the folders in the directory to find ModelData
    path = os.getcwd()
    for filepath in pathlib.Path(path).glob('*/'): 
        if(filepath.name == "ModelData" ):
            source = filepath
    return source



def MoveINData():
    """
    Move the folders IN and ModelData to input
    """
    path_IN = RenameUnzippedSolverData()
    path_input = CreateFolders()
    print(path_IN)
    print (path_input)
    
    shutil.move(path_IN,path_input)
    
    #shutil.move(path_model_data, path_input)
   
   
def MoveModelData():
    """
    Move the ModelData folder to the input folder
    """
    path = os.getcwd()
    model_data = os.path.join(path,r'ModelData')
    for filepath in pathlib.Path(path).glob('*/'): 
        if(filepath.name == "input" ):
            shutil.move(model_data ,filepath)


def MoveBackModelData():
    """
    Move the ModelData folder from the input folder to the current directory
    """
    path = os.getcwd()
    print(path)
    for filepath in pathlib.Path(path).glob('*/*'): 
        #print(filepath.name)
        if(filepath.name == "ModelData"):
            print(filepath, path)
            real_dst = os.path.join(path, os.path.basename(filepath))
            shutil.move(filepath,real_dst)





def commandPrompt():
    """
    Launch the simmulation automatically
    """
    os.system('cmd /c "stRoussetRunner.exe -i Config"')

#SelectSolverDataZip()
#print(p)
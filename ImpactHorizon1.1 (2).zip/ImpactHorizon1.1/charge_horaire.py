import os
import pathlib
import xlsxwriter
import collections

import xml.etree.ElementTree as ET
tree = ET.parse('Solution.xml')
root = tree.getroot()



keys = list(root[8][0].attrib.keys())
tools = []
SD = []
ED = []
d = []
start_dates = []
end_dates = []
for i in range(len(root[8])):
    tools.append(root[8][i].get('ToolID'))
    #print(root[8][i].get('ToolID'),root[8][i].get('StartDateTime'),root[8][i].get('EndDateTime'))
    d.append([root[8][i].get('ToolID'),root[8][i].get('StartDateTime'),root[8][i].get('EndDateTime')])
    #data = dict([(key, []) for key in tools])
    #data[root[8][i].get('ToolID')] = [root[8][i].get('StartDateTime'),root[8][i].get('EndDateTime')]
#print(d)
unique_tools_id = set(tools)
data = dict([(key, []) for key in unique_tools_id])  
#print(unique_tools_id)

    
occurrences = collections.Counter(tools)#pour savoir la taille de la liste des dates selon l'id
print(occurrences)


while(unique_tools[0] in d):
    start_dates.append(d[d.index(unique_tools[0][1])
    
print(start_dates)



 






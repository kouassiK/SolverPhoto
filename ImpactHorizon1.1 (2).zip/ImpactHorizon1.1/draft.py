from tkinter import *
from tkinter import ttk

def displayParameters():
    global solving_duration
    global origin_schedule
    global moves_window
    global weight_moves
    global weight_cycletime
    global weight_tsi
    global alpha_tsi
    global weight_high_priority
    global weight_medium_priority
    global weight_low_priority
    global weight_focus
    global weight_shiftonline
    global skip_hold
    global files_separator


    edit_solving_duration = solving_duration.get()
    edit_origin_schedule = origin_schedule.get()
    edit_moves_window = moves_window.get()
    edit_weight_moves = weight_moves.get()
    edit_weight_cycletime = weight_cycletime.get()
    edit_weight_tsi = weight_tsi.get()
    edit_alpha_tsi = alpha_tsi.get()
    edit_weight_high_priority = weight_high_priority.get()
    edit_weight_medium_priority = weight_medium_priority.get()
    edit_weight_low_priority = weight_low_priority.get()
    edit_weight_focus = weight_focus.get()
    edit_weight_shiftonline = weight_shiftonline.get()
    edit_skip_hold = skip_hold.get()


    print(edit_solving_duration, edit_origin_schedule, edit_moves_window, edit_weight_moves,edit_weight_cycletime, 
    edit_weight_tsi, edit_alpha_tsi, edit_weight_high_priority , edit_weight_medium_priority, edit_weight_low_priority, 
    edit_weight_focus, edit_weight_shiftonline, edit_skip_hold )

root = Tk() 

cadre = Frame(root)
cadre.pack(padx = 5, pady = 5)

label1 = Label(cadre, text= "SCHEDULER_PARAMETERS_PATH")
label1.pack(padx = 5, pady = 5, side = BOTTOM)

label2 = Label(cadre, text= "SOLVING_DURATION_IN_MINUTES")
label2.pack(padx = 5, pady = 5, side = BOTTOM)

label3 = Label(cadre, text= "ORIGIN_OF_THE_SCHEDULE")
label3.pack(padx = 5, pady = 5, side = BOTTOM)

label4 = Label(cadre, text= "MOVES_WINDOW_IN_HOURS")
label4.pack(padx = 5, pady = 5, side = BOTTOM)

label5 = Label(cadre, text= "WEIGHT_OF_MOVES_CRITERION_ONLY_USED_IN_MULTICRITERIA_MODE")
label5.pack(padx = 5, pady = 5, side = BOTTOM)

label6 = Label(cadre, text= "WEIGHT_OF_CYCLETIME_CRITERION_ONLY_USED_IN_MULTICRITERIA_MODE")
label6.pack(padx = 5, pady = 5, side = BOTTOM)

label7 = Label(cadre, text= "WEIGHT_OF_TargetSatisfactionIndicator_CRITERION_ONLY_USED_IN_MULTICRITERIA_MODE")
label7.pack(padx = 5, pady = 5, side = BOTTOM)

label8 = Label(cadre, text= "ALPHA_FOR_TARGET_SATISFACTION_INDICATOR")
label8.pack(padx = 5, pady = 5, side = BOTTOM)

label9 = Label(cadre, text= "WEIGHT_FOR_HIGH_PRIORITY_LOTS_TO_COMPUTE_XFACTOR")
label9.pack(padx = 5, pady = 5, side = BOTTOM)

label10 = Label(cadre, text= "WEIGHT_FOR_MEDIUM_PRIORITY_LOTS_TO_COMPUTE_XFACTOR")
label10.pack(padx = 5, pady = 5, side = BOTTOM)

label11 = Label(cadre, text= "WEIGHT_FOR_LOW_PRIORITY_LOTS_TO_COMPUTE_XFACTOR")
label11.pack(padx = 5, pady = 5, side = BOTTOM)

label12 = Label(cadre, text= "WEIGHT_FOR_FOCUS_MOVES")
label12.pack(padx = 5, pady = 5, side = BOTTOM)

label13 = Label(cadre, text= "WEIGHT_FOR_SHIFTONLINE_MOVES")
label13.pack(padx = 5, pady = 5, side = BOTTOM)

label14 = Label(cadre, text= "SKIP_HOLD")
label14.pack(padx = 5, pady = 5, side = BOTTOM)

label15 = Label(cadre, text= "INPUT_FILES_VALUES_SEPARATOR")
label15.pack(padx = 5, pady = 5, side = BOTTOM)



solving_duration = Entry(cadre, width = 50)
solving_duration.pack(padx = 5, pady = 5, side = RIGHT)
solving_duration.focus_force()

origin_schedule = Entry(cadre, width = 50 )
origin_schedule.pack(padx = 5, pady = 5, side = RIGHT)
origin_schedule.focus_force()

moves_window = Entry(cadre, width = 50 )
moves_window.pack(padx = 5, pady = 5, side = RIGHT)
moves_window.focus_force()

weight_moves = Entry(cadre, width = 50)
weight_moves.pack(padx = 5, pady = 5, side = RIGHT)
weight_moves.focus_force()

weight_cycletime = Entry(cadre, width = 50)
weight_cycletime.pack(padx = 5, pady = 5, side = RIGHT)
weight_cycletime.focus_force()

weight_tsi = Entry(cadre, width = 50 )
weight_tsi.pack(padx = 5, pady = 5, side = RIGHT)
weight_tsi.focus_force()

alpha_tsi = Entry(cadre, width = 50)
alpha_tsi.pack(padx = 5, pady = 5, side = RIGHT)
alpha_tsi.focus_force()

weight_high_priority = Entry(cadre, width = 50 )
weight_high_priority.pack(padx = 5, pady = 5, side = RIGHT)
weight_high_priority.focus_force()

weight_medium_priority = Entry(cadre, width = 50)
weight_medium_priority.pack(padx = 5, pady = 5, side = RIGHT)
weight_medium_priority.focus_force()

weight_low_priority = Entry(cadre, width = 50)
weight_low_priority.pack(padx = 5, pady = 5, side = RIGHT)
weight_low_priority.focus_force()

weight_focus = Entry(cadre, width = 50 )
weight_focus.pack(padx = 5, pady = 5, side = RIGHT)
weight_focus.focus_force()

'''weight_shiftonline = Entry(cadre, width = 50 , show = "*")
weight_shiftonline(padx = 5, pady = 5, side = BOTTOM)
weight_shiftonline.focus_force()'''

skip_hold = Entry(cadre, width = 50 , show = "*")
skip_hold.pack(padx = 5, pady = 5, side = BOTTOM)
skip_hold.focus_force()


files_separator = Entry(cadre, width = 50 , show = "*")
files_separator.pack(padx = 5, pady = 5, side = BOTTOM)
files_separator.focus_force()


btnAffiche = Button(root,text = 'Imprime Console', command= displayParameters)

btnAffiche.pack(padx = 5, pady = 5)

root.mainloop()

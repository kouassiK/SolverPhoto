import os
import pathlib
import glob
import numpy as np
from matplotlib.widgets import TextBox
import matplotlib.pyplot as plt
import pandas as pd
import openpyxl
import xlsxwriter
from statistics import *
best_results,files,deviations = [],[], []
X, M, T = [], [], [] 
max_target, min_xFactor, max_moves = 0,0,0


def FindFiles(): 
    '''
    Stocker tous les fichiers Excel dans lesquels figurent les calculs de déviation 
    '''  
    global files
    for f in glob.glob("*.xlsx"):
        if(f.find("Deviation")== -1):
            files.append(f)
    print(files)
    return files

def FindDeviations():   
    global deviations
    for f in glob.glob("*.xlsx"):
        if(f.find("Deviation")!= -1):
            deviations.append(f)
    print(deviations)
    return deviations

def FindFile(name):   
    """
    Trouver le chemin du fichier dont le nom est en paramètre
    """
    #Check all the folders in the directory to find 
    source = ""
    path = os.getcwd()
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == name):
            source = filepath
            print("found")
    return source


def getXFactor(name):
    '''
    Trouver tous les XFactor de la simulation pour le fichier nommé name
    '''  
    priority = pd.read_excel(FindFile(name), sheet_name = 'MULTICRITERIA_MODE')
    df = pd.DataFrame(priority)
    xFactor_list = list(priority.iloc[:, 3])
    return xFactor_list

def getMoves(name): 
    '''
    Trouver tous les XFactor de la simulation pour le fichier nommé name
    ''' 
      
    priority = pd.read_excel(FindFile(name), sheet_name = 'MULTICRITERIA_MODE')
    df = pd.DataFrame(priority)
    moves_list = list(priority.iloc[:, 4])
    return moves_list
    

def getTarget(name):
    '''
    Trouver tous les XFactor de la simulation pour le fichier nommé name
    ''' 
      
    priority = pd.read_excel(FindFile(name), sheet_name = 'MULTICRITERIA_MODE')
    df = pd.DataFrame(priority)
    targetsatisfaction_list = list(priority.iloc[:, 5])
    return targetsatisfaction_list

def submit(text):
    ydata = eval(text)
    l.set_ydata(ydata)
    ax.set_ylim(np.min(ydata), np.max(ydata))
    plt.draw()


def plot_resultats(nameDeviation):
    '''
    Représentation graphique des résultats
    '''
    #print(best_results)
    '''
    Récupération des XFactor du fichier stockant les résultats de Deviation

    ''' 
    priority = pd.read_excel(FindFile(nameDeviation), sheet_name = nameDeviation.strip('Deviation_.xlsx'))
    df = pd.DataFrame(priority)
    MDevs_list = list(priority.iloc[:, 1])
    xFactorDevs_list = list(priority.iloc[:, 2]) 
    TDevs_list = list(priority.iloc[:, 3]) 

    #print(MDevs_list)
    #print(xFactorDevs_list)
    #print(TDevs_list)
    #Abscisses
    vecteurs = [1 , 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
    vecteurs2 = ['(1,1,1)',    
        '(1,0,0)','(0,1,0)' ,'(0,0,1)' ,
        '(10,1,1)' ,'(1,10,1)', '(1,1,10)',
        '(100,1,1)' ,'(1,100,1)', '(1,1,100)',
        '(100,0.1,0.1)' ,'(0.1,100,0.1)', '(0.1,0.1,100)',
        '(100,0.01,0.01)' ,'(0.01,100,0.01)', '(0.01,0.01,100)']

######################################################### XFactor #########################################################
    #plt.rcParams['font.size'] = 5
    x_pos = np.arange(len(vecteurs))  
    bests_X = len(vecteurs)*[best_results[1]] #pour fixer 6 fois la meilleure valeur sur le graphique
    print(bests_X)
    fig, ax = plt.subplots()
    ax.errorbar(x_pos, bests_X, yerr=xFactorDevs_list, fmt='o',color='blue', capsize=5)
    ax.set_ylabel('X Factor')
    ax.set_xticks(x_pos)
    ax.set_xticklabels(vecteurs)
    ax.set_title('Multicriteria_' + nameDeviation.strip('Deviation_.xlsx'))
    ax.yaxis.grid(True)

    # Save the figure and show
    plt.tight_layout()
    
    plt.savefig('Deviation XFactor '+ nameDeviation.strip('.xlsxDeviation') +'.png')
    #Légende abscisses
    initial_text = "1(111)" + " 2(1,0,0)" + " 3(0,1,0)" +" 4(0,0,1)" +" 5(10,1,1)" +" 6(1,10,1)"+ " 7(1,1,10)"+ " 8(100,1,1)" +" 9(1,100,1)"+ " 10(1,1,100)"+" 11(100,0.1,0.1)" +" 12(0.1,100,0.1)"+ " 13(0.1,0.1,100)"+" 14(100,0.01,0.01)" +" 15(0.01,100,0.01)"+ " 16(0.01,0.01,100)"
                    

    axbox = plt.axes([0, -0.01, 1, 0.04])
    text_box = TextBox(axbox, 'Evaluate', initial=initial_text)
    text_box.on_submit(submit)

    plt.show()
    

   
##################################################       Moves   ################################
 
    bests_M = len(vecteurs)*[best_results[0]]
    print(bests_M)
    fig, ax = plt.subplots()
    ax.errorbar(x_pos, bests_M, yerr=MDevs_list, fmt='o',color='orange', capsize=5)
    ax.set_ylabel('Moves')
    ax.set_xticks(x_pos)
    ax.set_xticklabels(vecteurs)
    ax.set_title('Multicriteria_'  + nameDeviation.strip('Deviation_.xlsx'))
    ax.yaxis.grid(True)

    # Save the figure and show
    plt.tight_layout()
    plt.savefig('Deviation Moves '+ nameDeviation.strip('.xlsxDeviation') +'.png')
    axbox = plt.axes([0, -0.01, 1, 0.04])
    text_box = TextBox(axbox, 'Evaluate', initial=initial_text)
    text_box.on_submit(submit)
    plt.show()

    ##################################################Target Satisfcation##########################################
 
    bests_T = len(vecteurs)*[best_results[2]]
    fig, ax = plt.subplots()
    ax.errorbar(x_pos, bests_T, yerr=TDevs_list, fmt='o',color='blue', capsize=5)
    ax.set_ylabel('Target Satisfaction')
    ax.set_xticks(x_pos)
    ax.set_xticklabels(vecteurs)
    ax.set_title('Multicriteria_' + nameDeviation.strip('Deviation_.xlsx'))
    ax.yaxis.grid(True)

    # Save the figure and show
    plt.tight_layout()
    plt.savefig('Deviation Target Satisfaction '+ nameDeviation.strip('.xlsxDeviation') +'.png')
    axbox = plt.axes([0, -0.01, 1, 0.04])
    text_box = TextBox(axbox, 'Evaluate', initial=initial_text)
    text_box.on_submit(submit)

    plt.show()

def plot_moyennes():



def fill_deviation(name):
    '''
    Créer un fichier Excel nommé Deviation + nom instance pour stocker les résultats de la déviation
    '''
    global best_results
    global X
    global M
    global T
    xFactor_list = getXFactor(name)
    min_xFactor = min(xFactor_list)

    moves_list = getMoves(name)
    max_moves = max(moves_list)

    targetsatisfaction_list  = getTarget(name)
    max_targetsatisfaction = max(targetsatisfaction_list)

    vecteurs = ['(1,1,1)',    
    '(1,0,0)','(0,1,0)' ,'(0,0,1)' ,
    '(10,1,1)' ,'(1,10,1)', '(1,1,10)',
    '(100,1,1)' ,'(1,100,1)', '(1,1,100)',
    '(100,0.1,0.1)' ,'(0.1,100,0.1)', '(0.1,0.1,100)',
    '(100,0.01,0.01)' ,'(0.01,100,0.01)', '(0.01,0.01,100)']

    workbook = xlsxwriter.Workbook("Deviation_" +name)
    worksheet = workbook.add_worksheet(name.strip('.xlsx'))
    worksheet.write('A1', 'Instance+ Vecteur') 
    worksheet.write('B1', 'DeviationMoves en %') 
    worksheet.write('C1', 'DeviationXFactor en %')
    worksheet.write('D1', 'DeviationTargetSatisfaction en %') 

    for i in range(1,len(vecteurs)+1):
        worksheet.write(i, 0, name + '' + vecteurs[i-1])
        worksheet.write(i, 1,((max_moves -  moves_list[i-1]) / max_moves )*100)#Moves
        worksheet.write(i, 2,((xFactor_list[i-1]- min_xFactor )/ min_xFactor)*100 )#X
        worksheet.write(i, 3 ,((max_targetsatisfaction -  targetsatisfaction_list[i-1])/ max_targetsatisfaction)*100) #Target
        


    workbook.close()
    best_results =[max_moves, min_xFactor, max_targetsatisfaction]
    #best_results contient les valeurs max de moves,min de Xfactor, et max target satisfaction 
    #X contient toutes les déviations par rapport au meilleur XFactor pour l'instance
    #M contient toutes les déviations par rapport au meilleur moves pour l'instance
    #T contient toutes les déviations par rapport au meilleur targetSatisfaction pour l'instance


'''l1 = FindFiles()
l2 = FindDeviations()

for f in l1 :
    fill_deviation(f)

for f in l2:
    plot_resultats(f)'''

fill_deviation('Solver_20160623_16h.xlsx')
plot_resultats('Deviation_Solver_20160623_16h.xlsx')

fill_deviation('Solver_20160623_17h.xlsx')
plot_resultats('Deviation_Solver_20160623_17h.xlsx')

fill_deviation('Solver_20160624_8h.xlsx')
plot_resultats('Deviation_Solver_20160624_8h.xlsx')

fill_deviation('Solver_20160624_9h.xlsx')
plot_resultats('Deviation_Solver_20160624_9h.xlsx')

fill_deviation('Solver_20160623_17h.xlsx')
plot_resultats('Deviation_Solver_20160623_17h.xlsx')

fill_deviation('Solver_20160627_8h.xlsx')
plot_resultats('Deviation_Solver_20160627_8h.xlsx')

fill_deviation('Solver_20160627_9h.xlsx')
plot_resultats('Deviation_Solver_20160627_9h.xlsx')

fill_deviation('Solver_20160627_10h.xlsx')
plot_resultats('Deviation_Solver_20160627_10h.xlsx')

fill_deviation('Solver_20160627_11h.xlsx')
plot_resultats('Deviation_Solver_20160627_11h.xlsx')

fill_deviation('Solver_20160627_12h.xlsx')
plot_resultats('Deviation_Solver_20160627_12h.xlsx')

fill_deviation('Solver_20160627_15h.xlsx')
plot_resultats('Deviation_Solver_20160627_15h.xlsx')

fill_deviation('Solver_20160627_16h.xlsx')
plot_resultats('Deviation_Solver_20160627_16h.xlsx')

fill_deviation('Solver_20200703_14h45.xlsx')
plot_resultats('Deviation_Solver_20200703_14h45.xlsx')

fill_deviation('Solver_20200709_11h.xlsx')
plot_resultats('Deviation_Solver_20200709_11h.xlsx')

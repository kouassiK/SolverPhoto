
my_string = 'A,B,C,D,E'
my_list = my_string.split(",")
print (my_list)
['A', 'B', 'C', 'D', 'E']
import os
import shutil
import pathlib
import zipfile
import Excel
import test
import subprocess as sbp
import tkinter as tkinter
from zipfile import ZipFile
from tkinter import *
import xlsxwriter
from random import *
import xml.etree.ElementTree as ET
from distutils.dir_util import copy_tree
from tkinter.filedialog import askdirectory
from tkinter.filedialog import askopenfilename
from tkinter.filedialog import askopenfile

solving_duration = 0
origin_schedule = ""
moves_window = 0
weight_moves = 0 
weight_cycletime = 0
weight_tsi = 0
alpha_tsi = 0
weight_high_priority = 0
weight_medium_priority = 0
weight_low_priority = 0
weight_focus = 0
weight_shiftonline = 0
skip_hold = " "
files_separator = " "

origin = ""
p = " "

param1 = 0
param2 = 0
param3 = 0
param4 = 0
param5 = 0
param6 = 0
param7 = 0
param8 = 0




#################################Select zip file, create folders and get the origin#############

def SelectSolverDataZip():
    """
    Select the path to the data's folder to unzip
    Return the name of the zip folder
    """
    global p
    tkinter.Tk().withdraw()
    path = askopenfile()
    #print(path.name.strip('.zip'))
    #p = os.path.basename(path)
    #print(path.name)
    p = os.path.basename(path.name.strip('.zip'))
    return path.name

def UnzipSolverData():
    """
    Unzip the zip file (argument) in the current directory
    """
    filename = SelectSolverDataZip()
    with ZipFile(filename, 'r') as zip:
        zip.printdir()
        zip.extractall()
        
    return filename

def RenameUnzippedSolverData():
    """
    Rename the unzipped Solver data to IN
    """
    current_directory = os.getcwd()
    old_path = UnzipSolverData().strip('.zip')#to get the path without the .zip 
    print(old_path)
    filename = os.path.join(current_directory,os.path.basename(old_path))
    
    #Create path name for input folder
    IN = os.path.join(current_directory,r'IN')
    os.rename(filename,IN)
    return IN



##################################################################################################

def CreateFolders():
    """
    Create input and output folders which contain the data and the result of each run of the simulation
    Return input path
    """
    
    current_directory = os.getcwd()
    #Create path name for input folder
    input_folder = os.path.join(current_directory,r'input')
    #Create path name for output folder
    output_folder = os.path.join(current_directory,r'output')
    #Create output_folder if they don't exist
    if not os.path.exists(output_folder) and not os.path.exists(input_folder):
        #Create input_folder and output_folder
        os.makedirs(input_folder)
        os.makedirs(output_folder)
    else:
        #delete input folder
        shutil.rmtree(input_folder)
        #delete output folder
        shutil.rmtree(output_folder)
        #Recreate input_folder and output_folder
        os.makedirs(input_folder)
        os.makedirs(output_folder)
    
    return input_folder
        

def FindModelData():   
    """
    Find ModelData folder path
    """
    #Check all the folders in the directory to find ModelData
    path = os.getcwd()
    for filepath in pathlib.Path(path).glob('*/'): 
        if(filepath.name == "ModelData" ):
            source = filepath
    return source



def MoveINData():
    """
    Move the folders IN and ModelData to input
    """
    path_IN = RenameUnzippedSolverData()
    path_input = CreateFolders()
    print(path_IN)
    print (path_input)
    
    shutil.move(path_IN,path_input)
    
    #shutil.move(path_model_data, path_input)
   
   
def MoveModelData():
    """
    Move the ModelData folder to the input folder
    """
    path = os.getcwd()
    model_data = os.path.join(path,r'ModelData')
    for filepath in pathlib.Path(path).glob('*/'): 
        if(filepath.name == "input" ):
            shutil.move(model_data ,filepath)


def MoveBackModelData():
    """
    Move the ModelData folder from the input folder to the current directory
    """
    path = os.getcwd()
    print(path)
    for filepath in pathlib.Path(path).glob('*/*'): 
        #print(filepath.name)
        if(filepath.name == "ModelData"):
            print(filepath, path)
            real_dst = os.path.join(path, os.path.basename(filepath))
            shutil.move(filepath,real_dst)


def commandPrompt():
    """
    Launch the simmulation automatically
    """
    os.system('cmd /c "stRoussetRunner.exe -i Config"')

#problématique
def launchScheduler():
    """
    Launch the schedulizer automatically
    """   
    path = os.getcwd()
    #print(os.path.dirname(path))
    schedulizer_name = os.path.dirname(path) + ("\schedulizer")
    print(schedulizer_name)
    #os.startfile(schedulizer_name)


def GetOrigin():
    global origin
    path = os.getcwd()
    
    #print(path)
    for filepath in pathlib.Path(path).glob('**/*'): 
        #print(filepath.name)
        if(filepath.name == "ToolStatuses.txt"):
            f = open(filepath,'r')
            lines = f.readlines()
            line = lines[1] #Get the second line
            t = line.split(';') #get table of value separated by semi colon
            origin = t[4]
            start = True
            f.close()

#def deleteEmptyLine():

def getValues():

    '''solving_duration = IntVar()
    #origin_schedule = origin #StringVar()
    moves_window = IntVar()
    weight_moves = IntVar()
    weight_cycletime = IntVar()
    weight_tsi = IntVar()
    alpha_tsi = IntVar()
    weight_high_priority = IntVar()
    weight_medium_priority = IntVar()
    weight_low_priority = IntVar()
    weight_focus = IntVar()
    weight_shiftonline = IntVar()
    skip_hold = StringVar()
    files_separator = StringVar()'''

    elem1 = solving_duration.get()
    elem2 = origin_schedule.get() #origin found in ToolStatuses.txt
    elem3 = moves_window.get()
    elem4 = weight_moves.get()
    elem5 = weight_cycletime.get()
    elem6 = weight_tsi.get()
    elem7 = alpha_tsi.get()
    elem8 = weight_high_priority.get()
    elem9 = weight_medium_priority.get()
    elem10 = weight_low_priority.get()
    elem11 = weight_focus.get()
    elem12 = weight_shiftonline.get()
    elem13 = skip_hold.get()
    elem14 = files_separator.get()

    '''param1 = uniform(0.1, 0.5)
    param2 = uniform(0.1, 0.5)
    param3 = uniform(0.1, 0.5)
    param4 = uniform(0.5, 1)
    param5 = uniform(0.1, 0.5)
    param6 = uniform(0.1, 0.5)
    param7 = uniform(0.1, 0.5)
    param8 = uniform(0.1, 0.5)
    print(param1,param2,param3,param4,param5,param6,param7,param8)'''

    #print(elem1, elem2, elem3, elem4,elem5,elem6,elem7,elem8,elem9,elem10,elem11,elem12,elem13,elem14)
    result = [elem1, elem2, elem3, elem4,elem5,elem6,elem7,elem8,elem9,elem10,elem11,elem12,elem13,elem14]

    """
    Edit the Config file with the new parameters(in newParameters) entered in the the form
    """
    path = os.getcwd()
    lst = []
    newParameters = ["input","output","parameters.parameters.xml"] + result
    i = 0
    for filepath in pathlib.Path(path).glob('**/*'): 
        if(filepath.name == "Config" ):
            f = open(filepath,'r')
            for line in f:
                line = line.replace(line.partition("=")[2],newParameters[i])
                lst.append(line)
                i = i + 1
            f.close()
            f = open("Config","w")
            for line in lst:
                if(line.find("ORIGIN_OF_THE_SCHEDULE") != -1):
                    f.write(line)
                else:
                    f.write(line + "\n")
            f.close()

                        #Run simulation
            commandPrompt()

            test.MoveSolution()
            ExcelFileName = p
            ParametersValues = result
            f = test.FindSolutionPath()
            print(f)
            ResultValues = test.SaveValues(f)
            name = ExcelFileName + '.xlsx'
            #print(ExcelFileName)
            Excel.Edit(name , ParametersValues , ResultValues)
            #w = moves_window.get()
            #os.rename("Solution.xml", p + w.strip('\n') +"h" +".xml")

def Refresh():
    global param1
    global param2
    global param3
    global param4
    global param5
    global param6
    global param7
    global param8
    global Vecteur

    param1 = uniform(0.1, 0.5)
    param2 = uniform(0.1, 0.5)
    param3 = uniform(0.1, 0.5)

    V = [0.01, 0.1, 1 ,10, 100]



    param4 = choice(V) #high
    param5 = choice(V) #medium
    param6 =  choice(V)    #low

    param7 = uniform(0.1, 0.5)
    param8 = uniform(0.1, 0.5)

    weight_moves.delete(0, END)
    weight_moves.insert(END, 1)

    weight_cycletime.delete(0, END)
    weight_cycletime.insert(END, 1)
    
    weight_tsi.delete(0, END)
    weight_tsi.insert(END, 1)

    weight_high_priority.delete(0, END)
    weight_high_priority.insert(END, param4)

    weight_medium_priority.delete(0, END)
    weight_medium_priority.insert(END, param5)

    weight_low_priority.delete(0, END)
    weight_low_priority.insert(END, param6)

    weight_focus.delete(0, END)
    weight_focus.insert(END, 1)

    weight_shiftonline.delete(0, END)
    weight_shiftonline.insert(END,1)

   


def Interface():
    
    root = Tk()
    root.geometry('600x900')
    root.title("Config Form")

    global solving_duration
    global origin_schedule
    global moves_window
    global weight_moves
    global weight_cycletime
    global weight_tsi
    global alpha_tsi
    global weight_high_priority
    global weight_medium_priority
    global weight_low_priority
    global weight_focus
    global weight_shiftonline
    global skip_hold
    global files_separator


    solving_duration = IntVar()
    origin_schedule = StringVar()
    moves_window = IntVar()
    weight_moves = IntVar()
    weight_cycletime = IntVar()
    weight_tsi = IntVar()
    alpha_tsi = IntVar()
    weight_high_priority = IntVar()
    weight_medium_priority = IntVar()
    weight_low_priority = IntVar()
    weight_focus = IntVar()
    weight_shiftonline = IntVar()
    skip_hold = StringVar()
    files_separator = StringVar()

    GetOrigin()

    label_2 = Label(root, text="SOLVING_DURATION_IN_SECONDS",width=60,font=("bold", 8))
    label_2.place(x=-99,y=50)
    solving_duration = Entry(root)
    solving_duration.insert(END,300)
    solving_duration.place(x=260,y=50)

    label_3 = Label(root, text="ORIGIN_OF_THE_SCHEDULE",width=60,font=("bold", 8))
    label_3.place(x=-110,y=100)
    origin_schedule = Entry(root) #Default value of the origin
    origin_schedule.insert(END, origin)
    origin_schedule.place(x=260,y=100)

    label_4 = Label(root, text="MOVES_WINDOW_IN_HOURS",width=60,font=("bold", 8))
    label_4.place(x=-110,y=150)
    moves_window= Entry(root)
    moves_window.insert(END, 4)
    moves_window.place(x=260,y=150)

    label_5 = Label(root, text="WEIGHT_OF_MOVES",width=60,font=("bold", 8))
    label_5.place(x=-130,y=200)
    weight_moves = Entry(root)
    #weight_moves.insert(END, 1)
    weight_moves.place(x=260,y=200)

    label_6 = Label(root, text="WEIGHT_OF_CYCLETIME",width=60,font=("bold", 8))
    label_6.place(x=-120,y=250)
    weight_cycletime = Entry(root)
    #weight_cycletime.insert(END, 1)
    weight_cycletime.place(x=260,y=250)

    label_7 = Label(root, text="WEIGHT_OF_TargetSatisfactionIndicator",width=70,font=("bold", 8))
    label_7.place(x=-110,y=300)
    weight_tsi = Entry(root)
    #weight_tsi.insert(END, 1)
    weight_tsi.place(x=260,y=300)

    label_8 = Label(root, text="ALPHA_FOR_TARGET_SATISFACTION_INDICATOR",width=80,font=("bold", 8))
    label_8.place(x=-108,y=350)
    alpha_tsi = Entry(root)
    alpha_tsi.insert(END,1)
    alpha_tsi.place(x=260,y=350)

    label_9 = Label(root, text="WEIGHT_FOR_HIGH_PRIORITY_LOTS",width=60,font=("bold", 8))
    label_9.place(x=-90,y=400)
    weight_high_priority = Entry(root)
    weight_high_priority.insert(END, 1)
    weight_high_priority.place(x=260,y=400)

    label_10 = Label(root, text="WEIGHT_FOR_MEDIUM_PRIORITY_LOTS",width=60,font=("bold", 8))
    label_10.place(x=-80,y=450)
    weight_medium_priority = Entry(root)
    weight_medium_priority.insert(END, 1)
    weight_medium_priority.place(x=260,y=450)

    label_11 = Label(root, text="WEIGHT_FOR_LOW_PRIORITY_LOTS",width=60,font=("bold", 8))
    label_11.place(x=-90,y=500)
    weight_low_priority = Entry(root)
    weight_low_priority.insert(END, 1)
    weight_low_priority.place(x=260,y=500)

    label_12 = Label(root, text="WEIGHT_FOR_FOCUS_MOVES",width=60,font=("bold", 8))
    label_12.place(x=-100,y=550)
    weight_focus = Entry(root)
    weight_focus.insert(END, 1)
    weight_focus.place(x=260,y=550)


    label_13 = Label(root, text="WEIGHT_FOR_SHIFTONLINE_MOVES",width=80,font=("bold", 8))
    label_13.place(x=-140,y=600)
    weight_shiftonline = Entry(root)
    weight_shiftonline.insert(END,1)
    weight_shiftonline.place(x=260,y=600)

    label_14 = Label(root, text="SKIP_HOLD",width=60,font=("bold", 8))
    label_14.place(x=-110,y=650)
    skip_hold = Entry(root)
    skip_hold.insert(END, "yes")
    skip_hold.place(x=260,y=650)

    label_15 = Label(root, text="INPUT_FILES_VALUES_SEPARATOR",width=70,font=("bold", 8))
    label_15.place(x=-110,y=700)
    files_separator = Entry(root)
    files_separator.insert(END, ";")
    files_separator.place(x=260,y=700)


    Button(root, text='Submit',width=20,bg='brown',fg='white',command = getValues).place(x=200,y=750)
    #Button(root, text='Random',width=20,bg='brown',fg='white',command = Refresh).place(x=10,y=750)

    root.mainloop()

MoveINData()
MoveModelData()
Interface()

